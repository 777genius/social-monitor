import { describe, expect, it } from "vitest";
import {
  RetainedRecordKind as Kind, RetainedMemberRole as Role, RetainedPreparation as Preparation,
  RetainedTargetKind as TargetKind, RetainedTopology as Topology, RetainedResourceLifecycle as Lifecycle,
  RetainedResourceDisposition as Disposition, RetainedServiceObservation as ServiceObservation,
  RetainedManagerActive, RetainedManagerSubstate, RetainedManagerLoad, RetainedRetirementStep as Step,
  RetainedKernelRemoval, RetainedTaskHold, RetainedPidfdSemantics, RetainedJobResult,
  parseScopedRetainedRecord, parseScopedRetainedRecordBytes, parseScopedRetainedPublicationEvents, parseScopedRetainedPublicationEventsBytes, retainedResourceBytes,
  retainedResourceDigest as digest, retainedResourceLocator, retainedResourceNames,
  type ScopedRetainedRecord, type ScopedRetainedTarget, type RetainedRecordData, type ScopedRetainedPublicationEvents,
} from "../scoped-retained-resource-contract";
import { RetainedChainState, RetainedValidationMode as Mode, validateScopedRetainedChain, type RetainedChainExpectation } from "../scoped-retained-resource-validation";
import {
  ScopedEnqueueActorRole as ActorRole, ScopedActorDischargeMethod as DischargeMethod,
  parseScopedOperation, parseScopedReceipt, parseScopedStartCorrelation, validateScopedCollectedEvidence,
  scopedDigest, ScopedTerminationKind,
} from "../scoped-termination-contract";

type Mutable<T> = T extends readonly (infer V)[] ? Mutable<V>[] : T extends object ? { -readonly [K in keyof T]: Mutable<T[K]> } : T;
type Edit = (record: Mutable<ScopedRetainedRecord>) => void;
type EventEdit = (events: Mutable<ScopedRetainedPublicationEvents>, record: ScopedRetainedRecord) => void;
// Explicit synthetic observations for a DATA-only contract. These counters are
// test facts; they do not mint an original native observation or release tail.
const stamp = (atEpochMs: number, generation: number, phase: number) => ({ sequence: atEpochMs * 65536 + generation * 8 + phase, atEpochMs });
const project = (record: ScopedRetainedRecord): Mutable<ScopedRetainedPublicationEvents> => ({
  recordDigest: digest(record), producerId: record.publication.producerId, generation: record.publication.generation,
  admitted: { ...record.publication.admitted }, durable: stamp(record.publication.admitted.atEpochMs + 1, record.publication.generation, 1),
  readback: stamp(record.publication.admitted.atEpochMs + 2, record.publication.generation, 2),
  heldReread: record.kind === Kind.ActorAdmission ? stamp(record.publication.admitted.atEpochMs + 3, record.publication.generation, 3) : null,
  finalValidated: stamp(record.publication.admitted.atEpochMs + (record.kind === Kind.ActorAdmission ? 4 : 3), record.publication.generation, 4),
});
const selectedEvents = (events: readonly ScopedRetainedPublicationEvents[], records: readonly ScopedRetainedRecord[]) =>
  events.filter(e => records.some(r => digest(r) === e.recordDigest));
const H = (digit: string): string => digit.repeat(64);
const U = (digit: string): string => `${digit.repeat(8)}-${digit.repeat(4)}-${digit.repeat(4)}-${digit.repeat(4)}-${digit.repeat(12)}`;
const I = (digit: string): string => digit.repeat(32);
interface FixtureOptions {
  role?: Role; keyed?: boolean; runtimeProviders?: boolean; twoProviders?: boolean; preparation?: Preparation; payloadGateCreated?: boolean;
  neverCreated?: boolean; noReservations?: boolean; actualStart?: number; allowance?: number; edit?: Edit; eventEdit?: EventEdit; admissionBase?: number;
}

/** Explicit TEST-only normalized data. No files, actors, manager/kernel calls or
 * credentials. Changes are re-digested through successors, so negative tests
 * exercise semantic predicates rather than merely breaking a checksum. */
function fixture(options: FixtureOptions = {}) {
  const records: ScopedRetainedRecord[] = [];
  let targetDigest = "", generation = 0;
  // Early completion compresses only cleanup-stage observations. Preparation
  // has the same bytes and never knows which first-cleanup start will occur.
  const cleanupTime = (at: number): number => options.actualStart === undefined ? at : options.actualStart + Math.floor((at - 5000) / 10);
  const add = <K extends Kind>(kind: K, data: RetainedRecordData[K], at: number): ScopedRetainedRecord<K> => {
    const record = { schemaVersion: 2, kind, targetDigest, data: JSON.parse(JSON.stringify(data)), publication: {
      producerId: "TEST-producer", generation: ++generation, admitted: stamp(at, generation, 0),
    } } as Mutable<ScopedRetainedRecord>;
    if (options.actualStart !== undefined && ![Kind.Target, Kind.Reservation, Kind.ResourceObligation, Kind.ResourceBinding,
      Kind.Correlation, Kind.ActorAdmission, Kind.ServiceAdmission, Kind.PayloadGate].includes(kind)) {
      const shift = (value: unknown): void => {
        if (!value || typeof value !== "object") return;
        for (const [key, entry] of Object.entries(value)) {
          if ((key.endsWith("AtEpochMs") || key === "atEpochMs") && typeof entry === "number" && entry >= 5000 && key !== "startedAtEpochMs")
            (value as Record<string, unknown>)[key] = cleanupTime(entry);
          else shift(entry);
        }
      };
      shift(record);
    }
    options.edit?.(record);
    record.publication.admitted = stamp(record.publication.admitted.atEpochMs, record.publication.generation, 0);
    if (record.kind === Kind.Target) targetDigest = digest(record.data);
    record.targetDigest = targetDigest;
    records.push(record as ScopedRetainedRecord);
    return record as ScopedRetainedRecord<K>;
  };
  const role = options.runtimeProviders || options.keyed ? Role.Runtime : options.role ?? Role.FixtureHelper;
  const row = (role: Role, digit: string): ScopedRetainedTarget["allocations"][number] => ({
    allocationId: `TEST-P-${digit}`, startId: U(digit), allocationDigest: H(digit), permissionDigest: H("d"),
    installationAssociationDigest: H("e"), role, purpose: "TEST-qualification", grantDigest: [Role.Runtime, Role.Provider].includes(role) ? H("f") : null,
    installedGrantDigest: [Role.Runtime, Role.Provider].includes(role) ? H("f") : null,
    unit: [Role.Runtime, Role.Controller].includes(role) ? `subscription-runtime-ordinary-${U(digit)}.service` : role === Role.Provider ? `subscription-runtime-hosted-${U(digit)}.service` :
      role === Role.Qualification ? `subscription-runtime-qualification-${H("a")}.service` : role === Role.QRoot ? `subscription-runtime-qroot-${H("a")}.service` : "TEST-finite-helper.service",
    qualificationLocator: H("c"), qualificationId: [Role.Qualification, Role.QRoot].includes(role) ? H("a") : null,
    leafProfileDigest: H("a"), effectiveFilterPolicyDigest: H("b"), requiredFilterDigests: [H("f")],
  });
  const allocationRows = [row(role, "1"), ...(options.runtimeProviders ? [row(Role.Provider, "2"), ...(options.twoProviders ? [row(Role.Provider, "3")] : [])] : [])];
  const installation = { installationId: "TEST-installation", bootId: "TEST-boot", hostId: "TEST-host", namespaceDigest: H("a"), managerDigest: H("b"), producerId: "TEST-producer" };
  allocationRows.forEach(a => { (a as Mutable<typeof a>).installationAssociationDigest = digest(installation); });
  const targetRecord = add(Kind.Target, {
    scopeDigest: H("c"), kind: options.keyed ? TargetKind.KeyedChild : TargetKind.OrdinaryAllocation,
    topology: [Role.Runtime, Role.Provider].includes(role) ? Topology.RuntimeWithProviders : Topology.SingleOwnedService,
    installation,
    qualificationLocator: H("c"), workEndEpochMs: 10000,
    originalCleanupAuthority: { attemptId: U("f"), deadlineEpochMs: 20000, totalAllowanceMs: options.allowance ?? 15000, N: 7, joinDigest: H("e") },
    keyed: options.keyed ? { authorityDigest: H("f"), slotId: "TEST-slot", childAllocationId: allocationRows[0]!.allocationId,
      parentRuntimeAllocationId: "TEST-parent-P", parentRuntimeStartDigest: H("d"), dispatchIntentDigest: H("c"), dispatchIntentGeneration: 1 } : null,
    ordinaryAllocationId: options.keyed ? null : allocationRows[0]!.allocationId, allocations: allocationRows,
  }, 100);
  const t = targetRecord.data, originalAuthorityDigest = digest(t.originalCleanupAuthority);
  const actualStart = options.actualStart ?? 5000;
  const cleanupAttempt = { originalAuthorityDigest, attemptId: t.originalCleanupAuthority.attemptId, startedAtEpochMs: actualStart,
    endEpochMs: Math.min(t.originalCleanupAuthority.deadlineEpochMs, actualStart + t.originalCleanupAuthority.totalAllowanceMs), joinDigest: t.originalCleanupAuthority.joinDigest };
  const locator = retainedResourceLocator(t), names = retainedResourceNames(locator);
  const obligation = add(Kind.ResourceObligation, { resourceDigest: locator, sliceUnit: names.sliceUnit, targetUnit: names.targetUnit,
    creationGateDigest: H("a"), lifecycle: Lifecycle.Declared, originalAuthorityDigest, installationAssociationDigest: digest(t.installation),
    manifest: { nonExecuting: true, requiresSlice: true, afterSlice: true, cpuWeight: 100, denyReuseRestartRecreation: true },
  }, 200);
  const reservations = options.noReservations ? [] : t.allocations.map((a, index) => add(Kind.Reservation, {
    reservationId: U(String(index + 3)), reservationGeneration: index + 1, startId: a.startId, startDigest: H(String(index + 3)),
    allocationDigest: a.allocationDigest, obligationDigest: digest(obligation), originalGateDigest: H(String(index + 5)),
    parentRuntime: a.role === Role.Provider ? { allocationId: t.allocations[0]!.allocationId, startDigest: H("3") } :
      a.role === Role.Runtime && t.keyed ? { allocationId: t.keyed.parentRuntimeAllocationId, startDigest: t.keyed.parentRuntimeStartDigest } : null,
  }, 300 + index * 3));
  const binding = options.neverCreated ? null : add(Kind.ResourceBinding, {
    obligationDigest: digest(obligation), installationAssociationDigest: digest(t.installation),
    identity: { sliceUnit: names.sliceUnit, invocationId: I("a"), controlGroup: names.controlGroup, kernel: { device: 29, inode: 3509189 } },
    retentionTarget: { unit: names.targetUnit, invocationId: I("b"), requires: [names.sliceUnit], after: [names.sliceUnit], nonExecuting: true, active: RetainedManagerActive.Active },
    cpuWeight: 100, creationStartedAtEpochMs: 320, pinnedBeforeAdmissionAtEpochMs: 350, directoryCustodyDigest: H("c"), eventsCustodyDigest: H("d"),
  }, 400);
  const state = options.preparation ?? (options.neverCreated ? Preparation.Reserved : Preparation.PayloadReleased);
  const rank = Object.values(Preparation).indexOf(state);
  const admissions = reservations.map((r, index) => {
    const a = t.allocations[index]!, base = (options.admissionBase ?? 500) + index * 1000, creator = a.role === Role.Provider ? "200:20" : `${100 + index * 10}:10`, submitter = `${101 + index * 10}:11`;
    // Actual creator group is independent of the retained parent resource.
    const creatorGroup = a.role === Role.Provider ? `${names.controlGroup}/${t.allocations[0]!.unit}` : "/TEST-root-owner.service";
    const correlation = rank < 2 ? null : add(Kind.Correlation, { reservationDigest: digest(r), bindingDigest: digest(binding), startDigest: r.data.startDigest,
      reservationGeneration: r.data.reservationGeneration, intendedUnit: a.unit, intendedControlGroup: `${names.controlGroup}/${a.unit}`,
      creatorPidBirth: creator, creatorControlGroup: creatorGroup,
    }, base);
    const gate = (options.payloadGateCreated ?? (rank >= 3)) ? add(Kind.PayloadGate, {
      reservationDigest: digest(r), bindingDigest: digest(binding), originalEnqueueGateDigest: r.data.originalGateDigest,
      custodyProducerId: "TEST-producer", originalGateDigest: H("89a"[index]!), payloadCustodyDigest: H("def"[index]!), createdAtEpochMs: base + 40,
    }, base + 50) : null;
    const retainedSubmitter = { pidBirth: submitter, controlGroup: creatorGroup };
    const actor = correlation ? add(Kind.ActorAdmission, { correlationDigest: digest(correlation), originalGateDigest: r.data.originalGateDigest, submitter: retainedSubmitter,
      chain: { schemaVersion: 1, correlationDigest: digest(correlation), submitterDigest: digest(retainedSubmitter), actors: [
        { role: ActorRole.Creator, pidBirth: creator, controlGroup: creatorGroup, parentPidBirth: null },
        { role: ActorRole.ManagerSubmitter, pidBirth: submitter, controlGroup: creatorGroup, parentPidBirth: creator },
      ] }, custodyProducerId: "TEST-producer", hold: RetainedTaskHold.AllTasks, pidfdSemantics: RetainedPidfdSemantics.WholeThreadGroupExit,
      holdDigest: H("a"), pidfdCustodyDigest: H("b"), tasks: [{ actorPidBirth: creator, taskBirths: [creator] }, { actorPidBirth: submitter, taskBirths: [submitter] }],
    }, base + 100) : null;
    const service = rank < 4 ? null : add(Kind.ServiceAdmission, { correlationDigest: digest(correlation), actorAdmissionDigest: digest(actor), acceptedAtEpochMs: base + 200,
      unit: a.unit, invocationId: I(String(index + 1)), invocationAnchor: { invocationId: I(String(index + 1)), kernel: { device: 29, inode: 8000 + index } },
      mainPidBirth: `${200 + index}:20`, controlGroup: `${names.controlGroup}/${a.unit}`, kernel: { device: 29, inode: 9000 + index },
      payloadAncestry: [{ pidBirth: `${200 + index}:20`, parentPidBirth: null, controlGroup: `${names.controlGroup}/${a.unit}` }],
      payloadCustodyDigest: gate?.data.payloadCustodyDigest ?? H("d"), closedPayloadGateDigest: gate?.data.originalGateDigest ?? H("e"), leafProfileDigest: a.leafProfileDigest,
      effectiveFilterPolicyDigest: a.effectiveFilterPolicyDigest, effectiveFilterAttachments: [H("f")],
    }, base + 300);
    return { r, actor, service, gate, preparation: { reservationDigest: digest(r), state,
      correlationDigest: correlation ? digest(correlation) : null, actorAdmissionDigest: actor ? digest(actor) : null,
      serviceAdmissionDigest: service ? digest(service) : null, payloadGateDigest: gate ? digest(gate) : null, enqueueReleasedAtEpochMs: rank >= 3 ? base + 150 : null,
      payloadReleasedAtEpochMs: rank >= 5 ? base + 350 : null } };
  });
  const closure = add(Kind.Closure, { cleanupAttempt, attemptDigest: digest(cleanupAttempt), closureGeneration: 1, admissionClosedAtEpochMs: 5000, admissionDenialDigest: H("a"),
    reservationDigests: reservations.map(digest), obligationDigests: [digest(obligation)], preparations: admissions.map(a => a.preparation),
  }, 6000);
  const attemptDigest = digest(closure.data.cleanupAttempt);
  const uncreated = binding ? null : add(Kind.ResourceUncreated, { obligationDigest: digest(obligation), closureDigest: digest(closure), creationGateDigest: obligation.data.creationGateDigest,
    closedAtEpochMs: 6200, noCreationAccepted: true,
  }, 6250);
  const queue = (observedAtEpochMs: number) => ({ managerDigest: t.installation.managerDigest,
    relevantUnits: [...t.allocations.map(a => a.unit), names.sliceUnit, names.targetUnit], jobs: [], observedAtEpochMs });
  const empty = add(Kind.EmptyProof, { attemptDigest, closureDigest: digest(closure), dispositions: admissions.map(({ r, actor, service, gate, preparation }) => ({
    payloadGateClosure: gate ? { payloadGateDigest: digest(gate), originalGateDigest: gate.data.originalGateDigest, payloadCustodyDigest: gate.data.payloadCustodyDigest, closedAtEpochMs: 6200 } : null,
    reservationDigest: digest(r), originalGateDigest: r.data.originalGateDigest, closedAtEpochMs: 6200, dischargedAtEpochMs: actor ? 6250 : null,
    discharge: actor ? { schemaVersion: 2, chainDigest: digest(actor.data.chain), fenceDigest: digest(closure), actors: actor.data.chain.actors.map((a, i) => ({ ...a,
      method: i === 0 ? DischargeMethod.ScopedAdmissionFence : DischargeMethod.PidfdExit,
    })) } : null,
    serviceObservation: service || preparation.enqueueReleasedAtEpochMs !== null ? ServiceObservation.NotFound : null, serviceAdmissionDigest: service ? digest(service) : null,
  })), resources: binding ? [{ disposition: Disposition.PositiveEmpty, obligationDigest: digest(obligation), bindingDigest: digest(binding),
    identityBefore: binding.data.identity, identityAfter: binding.data.identity, observedBeforeAtEpochMs: 6400, observedAfterAtEpochMs: 6500,
    nodes: [{ path: names.controlGroup, kernel: binding.data.identity.kernel, events: "populated 0\nfrozen 0\n", processes: "", children: [] }],
  }] : [{ disposition: Disposition.NeverCreated, obligationDigest: digest(obligation), uncreatedDigest: digest(uncreated) }], queueBefore: queue(6300), queueAfter: queue(6600),
  }, 7000);
  const steps = binding ? [{ bindingDigest: digest(binding), step: Step.StopTarget, unit: names.targetUnit }, { bindingDigest: digest(binding), step: Step.StopSlice, unit: names.sliceUnit }] : [];
  const intent = add(Kind.RetirementIntent, { attemptDigest, emptyProofDigest: digest(empty), closureDigest: digest(closure), steps }, 8000);
  const retiredManager = (unit: string, originalInvocationId: string, observedAtEpochMs: number): RetainedRecordData[Kind.RetirementFacts]["resources"][number]["target"] => ({ unit, originalInvocationId,
    load: RetainedManagerLoad.Loaded, active: RetainedManagerActive.Inactive, substate: RetainedManagerSubstate.Dead,
    currentInvocationId: "" as const, currentControlGroup: "" as const, observedAtEpochMs });
  const facts = add(Kind.RetirementFacts, { attemptDigest, emptyProofDigest: digest(empty), intentDigest: digest(intent),
    effects: steps.map((s, i) => ({ ...s, sliceIdentityBefore: s.step === Step.SliceAlreadyRetired ? null : binding!.data.identity,
      directoryCustodyDigest: binding!.data.directoryCustodyDigest, targetInvocationIdBefore: s.step === Step.StopTarget ? binding!.data.retentionTarget.invocationId : null,
      targetDependencyDigestBefore: s.step === Step.StopTarget ? digest(binding!.data.retentionTarget) : null,
      observedBeforeAtEpochMs: i === 0 ? 8050 : 8260, acceptedJobId: s.step === Step.SliceAlreadyRetired ? null : 40 + i, submittedAtEpochMs: 8100 + i * 200,
      completedAtEpochMs: 8200 + i * 200, result: RetainedJobResult.Done })),
    resources: binding ? [{ bindingDigest: digest(binding), target: retiredManager(names.targetUnit, binding.data.retentionTarget.invocationId, 8250),
      slice: retiredManager(names.sliceUnit, binding.data.identity.invocationId, 8600), kernel: {
        observation: RetainedKernelRemoval.PinnedEventsENODEVAndPathAbsent, pinnedDirectory: binding.data.identity.kernel,
        pinnedDirectoryNlink: 2, directoryCustodyDigest: binding.data.directoryCustodyDigest, eventsCustodyDigest: binding.data.eventsCustodyDigest,
        exactAbsentPath: names.controlGroup, conflictingReplacement: false, observedAtEpochMs: 8700,
      } }] : [], queueAfter: queue(8800),
  }, 9000);
  const publication = add(Kind.RetirementPublication, { attemptDigest, factsDigest: digest(facts), intentDigest: digest(intent), nativeProvenanceDigest: H("e") }, 10000);
  const final = add(Kind.FinalReceipt, { attemptDigest, closureDigest: digest(closure), emptyProofDigest: digest(empty), intentDigest: digest(intent), factsDigest: digest(facts), retirementPublicationDigest: digest(publication) }, 11000);
  const terminals = reservations.map((r, i) => add(Kind.OrdinaryTerminal, { attemptDigest, reservationDigest: digest(r), finalReceiptDigest: digest(final) }, 12000 + i * 10));
  if (options.keyed) add(Kind.KeyedTerminal, { attemptDigest, finalReceiptDigest: digest(final), keyedBindingDigest: digest(t.keyed), dispatchIntentDigest: t.keyed!.dispatchIntentDigest,
    ordinaryTerminalDigests: terminals.map(digest),
  }, 13000);
  const expected: RetainedChainExpectation = { targetDigest, originalAuthorityDigest, attemptDigest, reservationDigests: reservations.map(digest), obligationDigests: [digest(obligation)], payloadGateDigests: admissions.flatMap(a => a.gate ? [digest(a.gate)] : []) };
  const publicationEvents = records.map(record => {
    const events = project(record);
    options.eventEdit?.(events, record);
    return events;
  });
  return { records, publicationEvents, expected };
}
const read = (f: ReturnType<typeof fixture>, mode = Mode.ReadOnlyHistoricalData, now = 99000) => validateScopedRetainedChain(f.records, f.publicationEvents, f.expected, mode, now);
const fails = (edit: Edit, predicate: string, options: FixtureOptions = {}) => expect(() => read(fixture({ ...options, edit }))).toThrow(predicate);
const failsEvents = (eventEdit: EventEdit, predicate: string, options: FixtureOptions = {}) => expect(() => read(fixture({ ...options, eventEdit }))).toThrow(predicate);

describe("retained v2 causal publication DATA", () => {
  // Red predicate: truthful delayed D/R/H/F would require changing an already
  // published BODY or predicting its future completion inside canonical bytes.
  it("keeps one BODY and digest across distinct explicit delayed completions", () => {
    const f = fixture({ admissionBase: 900 });
    const actor = f.records.find(r => r.kind === Kind.ActorAdmission)!;
    const bytes = retainedResourceBytes(actor), bodyDigest = digest(actor);
    expect(actor.publication.admitted.atEpochMs).toBe(1000);
    for (const [d, r, h, final] of [[1040, 1042, 1044, 1045], [1041, 1043, 1046, 1049]]) {
      const projections = structuredClone(f.publicationEvents);
      const e = projections.find(e => e.recordDigest === bodyDigest)!;
      e.durable = stamp(d!, e.generation, 1); e.readback = stamp(r!, e.generation, 2);
      e.heldReread = stamp(h!, e.generation, 3); e.finalValidated = stamp(final!, e.generation, 4);
      expect(read({ ...f, publicationEvents: projections }).state).toBe(RetainedChainState.CompleteData);
      expect(parseScopedRetainedRecordBytes(bytes)).toEqual(actor);
      expect(retainedResourceBytes(actor)).toBe(bytes);
      expect(digest(actor)).toBe(bodyDigest);
    }
  });
  it("orders actual same-millisecond completions by distinct original sequences", () => {
    const f = fixture({ eventEdit: (e, record) => {
      const at = record.publication.admitted.atEpochMs;
      e.durable = stamp(at, e.generation, 1); e.readback = stamp(at, e.generation, 2);
      if (e.heldReread) e.heldReread = stamp(at, e.generation, 3);
      e.finalValidated = stamp(at, e.generation, 4);
    } });
    expect(read(f).state).toBe(RetainedChainState.CompleteData);
  });
  it("rejects the old future-bearing BODY and ActorAdmission shapes explicitly", () => {
    const actor = fixture().records.find(r => r.kind === Kind.ActorAdmission)!;
    expect(() => parseScopedRetainedRecord({ ...actor, publication: { producerId: actor.publication.producerId,
      generation: actor.publication.generation, admittedAtEpochMs: 1000, durableAtEpochMs: 1040, finalValidatedAtEpochMs: 1045,
    } })).toThrow("fields");
    expect(() => parseScopedRetainedRecord({ ...actor, data: { ...actor.data, finalHeldRereadAtEpochMs: 1044 } })).toThrow("fields");
  });

  // Red predicate: accepting a malformed or caller-mutable event map lets its
  // digest binding or causal observations change after the DATA boundary.
  it("parses closed canonical detached immutable publication event DATA", () => {
    const raw = fixture().publicationEvents.find(e => e.heldReread !== null)!;
    const bytes = retainedResourceBytes(raw), parsed = parseScopedRetainedPublicationEventsBytes(bytes);
    raw.durable.atEpochMs++;
    expect(retainedResourceBytes(parsed)).toBe(bytes);
    expect(Object.isFrozen(parsed)).toBe(true);
    expect(Object.isFrozen(parsed.admitted)).toBe(true);
    expect(Object.isFrozen(parsed.heldReread)).toBe(true);
    expect(() => parseScopedRetainedPublicationEvents({ ...parsed, nativeHandle: "TEST-forbidden" })).toThrow("fields");
    expect(() => parseScopedRetainedPublicationEvents({ ...parsed, durable: { ...parsed.durable, extra: true } })).toThrow("fields");
    expect(() => parseScopedRetainedPublicationEvents({ ...parsed, durable: { ...parsed.durable, sequence: 0 } })).toThrow("integer");
    expect(() => parseScopedRetainedPublicationEvents({ ...parsed, durable: { ...parsed.durable, atEpochMs: 0 } })).toThrow("integer");
    expect(() => parseScopedRetainedPublicationEvents({ ...parsed, durable: { ...parsed.durable, sequence: Number.MAX_SAFE_INTEGER + 1 } })).toThrow();
    expect(() => parseScopedRetainedPublicationEvents({ get recordDigest() { throw new Error("must not execute"); } })).toThrow("json_object");
    expect(() => parseScopedRetainedPublicationEventsBytes(bytes.replace('"generation":', '"generation":1,"generation":'))).toThrow("noncanonical_bytes");
    expect(() => parseScopedRetainedPublicationEventsBytes(bytes.trimEnd())).toThrow("noncanonical_bytes");
  });
  it("requires explicit events and checks the whole bounded map before missing completion", () => {
    const f = fixture(), first = f.publicationEvents[0]!;
    expect(read({ ...f, publicationEvents: [] })).toMatchObject({ state: RetainedChainState.Incomplete });
    expect(read({ ...f, publicationEvents: f.publicationEvents.slice(1) })).toEqual({
      state: RetainedChainState.Incomplete, missing: [`publication_events:${first.recordDigest}`],
    });
    expect(() => validateScopedRetainedChain(f.records, undefined as unknown as readonly unknown[], f.expected, Mode.ReadOnlyHistoricalData, 99000)).toThrow("publication_event_bound");
    expect(() => validateScopedRetainedChain(f.records, [...f.publicationEvents.slice(1), { ...first, extra: true }], f.expected, Mode.ReadOnlyHistoricalData, 99000)).toThrow("fields");
    expect(() => read({ ...f, publicationEvents: Array.from({ length: 4097 }, () => first) })).toThrow("publication_event_bound");
    expect(() => read({ ...f, publicationEvents: [...f.publicationEvents, first] })).toThrow("duplicate_publication_events");
    expect(() => read({ ...f, publicationEvents: [...f.publicationEvents, { ...first, recordDigest: H("f") }] })).toThrow("foreign_publication_events");
    const records = f.records.filter(r => digest(r) !== first.recordDigest);
    expect(() => read({ ...f, records })).toThrow("foreign_publication_events");
  });
  it.each(["producer", "generation", "admitted", "digest"])("rejects a foreign %s event binding", field => {
    const f = fixture();
    const e = f.publicationEvents[0]!;
    if (field === "producer") e.producerId = "TEST-foreign";
    if (field === "generation") e.generation++;
    if (field === "admitted") e.admitted.sequence++;
    if (field === "digest") e.recordDigest = H("f");
    expect(() => read(f)).toThrow(field === "digest" ? "foreign_publication_events" : "publication_event_binding");
  });

  // Red predicate: completion before its prerequisite, counter reuse, missing
  // actor reread, or future observations could otherwise admit causal fiction.
  it.each(["durable", "readback", "heldReread", "finalValidated"] as const)("rejects predating or duplicate %s observation", field => {
    for (const change of ["epoch", "sequence"] as const) {
      failsEvents((e, r) => {
        if (r.kind !== Kind.ActorAdmission) return;
        const previous = field === "durable" ? e.admitted : field === "readback" ? e.durable : field === "heldReread" ? e.readback : e.heldReread!;
        e[field]![change === "epoch" ? "atEpochMs" : "sequence"] = previous[change === "epoch" ? "atEpochMs" : "sequence"] - (change === "epoch" ? 1 : 0);
      }, "publication_event_order");
    }
  });
  it("requires H exactly for ActorAdmission and rejects counters reused across bodies", () => {
    failsEvents((e, r) => { if (r.kind === Kind.ActorAdmission) e.heldReread = null; }, "publication_event_hold");
    failsEvents((e, r) => { if (r.kind === Kind.Reservation) e.heldReread = stamp(e.readback.atEpochMs, e.generation, 3); }, "publication_event_hold");
    const f = fixture({ runtimeProviders: true });
    const reservations = f.records.filter(r => r.kind === Kind.Reservation);
    const e = f.publicationEvents.find(e => e.recordDigest === digest(reservations[0]))!;
    e.finalValidated.sequence = reservations[1]!.publication.admitted.sequence;
    expect(() => read(f)).toThrow("publication_event_sequence");
  });
  it("rejects reversed global clock observations and completion past observation time", () => {
    const f = fixture(), e = f.publicationEvents.find(e => e.heldReread !== null)!;
    const lastSequence = Math.max(...f.publicationEvents.map(e => e.finalValidated.sequence));
    [e.durable, e.readback, e.heldReread!, e.finalValidated].forEach((stamp, index) => { stamp.sequence = lastSequence + index + 1; });
    expect(() => read(f)).toThrow("publication_event_clock");
    failsEvents((e, r) => { if (r.kind === Kind.OrdinaryTerminal) e.finalValidated = stamp(99001, e.generation, 4); }, "future_publication");
  });
  it("rejects recorded enqueue release before completed ActorAdmission", () => {
    const f = fixture({ admissionBase: 900, preparation: Preparation.EnqueueReleased, eventEdit: (e, r) => {
      if (r.kind === Kind.ActorAdmission) {
        e.durable = stamp(1040, e.generation, 1); e.readback = stamp(1042, e.generation, 2);
        e.heldReread = stamp(1044, e.generation, 3); e.finalValidated = stamp(1051, e.generation, 4);
      }
    } });
    expect(() => read(f)).toThrow("enqueue_gate_time");
  });
});

describe("retained v2 bounded source/data contracts", () => {
  it("reads a complete durable chain after disposal and expiry, including SAME pinned inode with nlink 2", () => {
    const f = fixture();
    expect(read(f)).toMatchObject({ state: RetainedChainState.CompleteData, targetDigest: f.expected.targetDigest });
    expect(read(f, Mode.LiveData, 15000).state).toBe(RetainedChainState.CompleteData);
  });
  it.each([Role.Controller, Role.Qualification, Role.QRoot, Role.FixtureHelper, Role.FaultHelper])("accepts genuine ordinary %s names and actual null installed grants", role => {
    expect(read(fixture({ role })).state).toBe(RetainedChainState.CompleteData);
  });
  it("accepts genuine keyed runtime/provider composition and genuine parent associations", () => {
    expect(read(fixture({ keyed: true, runtimeProviders: true })).state).toBe(RetainedChainState.CompleteData);
  });
  it.each(Object.values(Preparation))("keeps every reserved obligation at preparation %s without fabricated admitted services", preparation => {
    expect(read(fixture({ preparation })).state).toBe(RetainedChainState.CompleteData);
  });
  it.each([false, true])("supports zero reservations and no invented Runtime, resource neverCreated=%s", neverCreated => {
    expect(read(fixture({ noReservations: true, neverCreated })).state).toBe(RetainedChainState.CompleteData);
  });
  it("accepts a closed never-created obligation; partial creation remains resource debt", () => {
    expect(read(fixture({ neverCreated: true })).state).toBe(RetainedChainState.CompleteData);
    fails(r => { if (r.kind === Kind.ResourceObligation) r.data.lifecycle = Lifecycle.CreationStarted; }, "uncreated_resource_debt", { neverCreated: true });
    fails(r => { if (r.kind === Kind.ResourceUncreated) { r.data.closedAtEpochMs = 6400; r.publication.admitted.atEpochMs = 6450; } }, "uncreated_resource_debt", { neverCreated: true });
  });
  it("accepts optional slice already-retired observation only with no invented stop job", () => {
    const f = fixture({ edit: r => {
      if (r.kind === Kind.RetirementIntent) r.data.steps[1]!.step = Step.SliceAlreadyRetired;
      if (r.kind === Kind.RetirementFacts) { r.data.effects[1]!.step = Step.SliceAlreadyRetired; r.data.effects[1]!.acceptedJobId = null; r.data.effects[1]!.sliceIdentityBefore = null; }
    } });
    expect(read(f).state).toBe(RetainedChainState.CompleteData);
  });
  it("requires canonical bytes, stable keys and immutable detached parsed data", () => {
    const raw = fixture().records[0]!;
    const parsed = parseScopedRetainedRecordBytes(retainedResourceBytes(raw));
    expect(digest(parsed)).toBe(digest(raw));
    expect(digest({ b: 2, a: 1 })).toBe(digest({ a: 1, b: 2 }));
    expect(Object.isFrozen(parsed.data)).toBe(true);
    expect(Object.isFrozen((parsed as ScopedRetainedRecord<Kind.Target>).data.allocations)).toBe(true);
    expect(() => parseScopedRetainedRecordBytes(JSON.stringify(raw))).toThrow("noncanonical_bytes");
    const bytes = retainedResourceBytes(raw);
    expect(() => parseScopedRetainedRecordBytes(bytes.replace('"schemaVersion":2', '"schemaVersion":1,"schemaVersion":2'))).toThrow("noncanonical_bytes");
    expect(() => parseScopedRetainedRecordBytes(bytes.replace('"schemaVersion":2', '"schemaVersion":2,"schemaVersion":2'))).toThrow("noncanonical_bytes");
  });
  it("rejects unknown/extra fields, invalid versions/enums, traversal, oversized and executable objects", () => {
    const r = fixture().records[0]!;
    expect(() => parseScopedRetainedRecord({ ...r, schemaVersion: 1 })).toThrow("literal");
    expect(() => parseScopedRetainedRecord({ ...r, kind: "future" })).toThrow("enum");
    expect(() => parseScopedRetainedRecord({ ...r, credentials: "TEST-invalid" })).toThrow("fields");
    expect(() => parseScopedRetainedRecord({ ...r, publication: { ...r.publication, generation: 0 } })).toThrow("integer");
    expect(() => parseScopedRetainedRecordBytes(" ".repeat(4 * 1024 * 1024 + 1))).toThrow("bytes_bound");
    expect(() => parseScopedRetainedRecord(new Date())).toThrow("json_object");
    expect(() => parseScopedRetainedRecord({ get schemaVersion() { throw new Error("must not execute"); } })).toThrow("json_object");
    const huge = structuredClone(r) as Mutable<ScopedRetainedRecord<Kind.Target>>;
    huge.data.allocations = Array.from({ length: 257 }, () => huge.data.allocations[0]!); huge.targetDigest = digest(huge.data);
    expect(() => parseScopedRetainedRecord(huge)).toThrow("array_bound");
    fails(r => { if (r.kind === Kind.Correlation) r.data.creatorControlGroup = "/x/../owner.service"; }, "group");
  });
  it("isolates scope/target/service/parent identities and exact full systemd hierarchy", () => {
    fails(r => { if (r.kind === Kind.ResourceObligation) r.data.sliceUnit = `subscription-runtime-hosted-${H("f")}.slice`; }, "resource_names_binding");
    fails(r => { if (r.kind === Kind.ResourceBinding) r.data.identity.controlGroup = "/subscription-runtime-hosted.slice/child.slice"; }, "retained_binding");
    fails(r => { if (r.kind === Kind.Correlation) r.data.creatorControlGroup = r.data.intendedControlGroup.slice(0, r.data.intendedControlGroup.lastIndexOf("/")); }, "correlation_binding");
    fails(r => { if (r.kind === Kind.Correlation) r.data.intendedControlGroup += "/nested"; }, "correlation_binding");
    fails(r => { if (r.kind === Kind.ResourceBinding) r.data.retentionTarget.after = []; }, "array_bound");
    fails(r => { if (r.kind === Kind.ResourceBinding) r.data.creationStartedAtEpochMs = 201; }, "retained_binding");
  });
  it("refuses fake ordinary keyed bindings, parent Runtime and grants, while keeping keyed policy strict", () => {
    fails(r => { if (r.kind === Kind.Reservation) r.data.parentRuntime = { allocationId: "TEST-fake", startDigest: H("a") }; }, "fabricated_parent_runtime");
    fails(r => { if (r.kind === Kind.Target) r.data.allocations[0]!.grantDigest = H("f"); }, "installed_grant");
    fails(r => { if (r.kind === Kind.Target) r.data.topology = Topology.RuntimeWithProviders; }, "runtime_composition");
    fails(r => { if (r.kind === Kind.Target) r.data.ordinaryAllocationId = "TEST-foreign"; }, "ordinary_target");
    fails(r => { if (r.kind === Kind.Target) { r.data.allocations[0]!.grantDigest = null; r.data.allocations[0]!.installedGrantDigest = null; } }, "keyed_target", { keyed: true });
    fails(r => { if (r.kind === Kind.Reservation) r.data.parentRuntime = null; }, "genuine_parent_runtime", { keyed: true });
    fails(r => { if (r.kind === Kind.Target) r.data.allocations[0]!.unit = "TEST-arbitrary.service"; }, "qualification_unit", { role: Role.Qualification });
  });
  it.each([Role.Qualification, Role.QRoot].flatMap(role => ["TEST-q", "a".repeat(63), "a".repeat(65), "g".repeat(64), "A".repeat(64)].map(id => [role, id] as const)))("rejects invalid %s id %s even with an exactly matching unit", (role, qualificationId) => {
      const f = fixture({ role, edit: r => {
        if (r.kind === Kind.Target) {
          const a = r.data.allocations[0]!;
          a.qualificationId = qualificationId;
          a.unit = `subscription-runtime-${role === Role.Qualification ? "qualification" : "qroot"}-${qualificationId}.service`;
        }
      } });
      expect(() => read(f)).toThrow();
  });
  it("rejects an admitted leaf that claims the retained parent kernel object even after leaf GC", () => {
    fails(r => { if (r.kind === Kind.ServiceAdmission) r.data.kernel = { device: 29, inode: 3509189 }; }, "cgroup_identity");
  });
  it("rejects a service leaf from another cgroup filesystem", () => {
    fails(r => { if (r.kind === Kind.ServiceAdmission) r.data.kernel.device = 999; }, "cgroup_filesystem");
  });
  it("rejects overlapping provider admissions claiming the same cgroup object", () => {
    fails(r => {
      if (r.kind === Kind.ServiceAdmission && r.data.unit.includes(U("2"))) {
        r.publication.admitted.atEpochMs = 2800;
      }
      if (r.kind === Kind.ServiceAdmission && r.data.unit.includes(U("3"))) r.data.kernel.inode = 9001;
    }, "cgroup_identity", { runtimeProviders: true, twoProviders: true, preparation: Preparation.ServiceAdmitted });
  });
  it("allows inode reuse in nonoverlapping historical admissions without claiming simultaneous existence", () => {
    expect(read(fixture({ runtimeProviders: true, twoProviders: true, edit: r => {
      if (r.kind === Kind.ServiceAdmission && r.data.unit.startsWith("subscription-runtime-hosted-")) r.data.kernel.inode = 9001;
    } })).state).toBe(RetainedChainState.CompleteData);
  });
  it("allows a descendant to reuse an absent historical leaf inode", () => {
    expect(read(fixture({ runtimeProviders: true, edit: r => {
      recursiveTree(r);
      if (r.kind === Kind.EmptyProof && r.data.resources[0]!.disposition === Disposition.PositiveEmpty) r.data.resources[0]!.nodes[2]!.kernel.inode = 9001;
    } })).state).toBe(RetainedChainState.CompleteData);
  });
  const recursiveTree: Edit = r => {
    if (r.kind === Kind.EmptyProof && r.data.resources[0]!.disposition === Disposition.PositiveEmpty) {
      const resource = r.data.resources[0]!, root = resource.nodes[0]!, unit = r.data.queueBefore.relevantUnits[0]!;
      root.children = [unit];
      resource.nodes.push({ path: root.path + "/" + unit, kernel: { device: 29, inode: 9000 }, events: "populated 0\n", processes: "", children: ["nested"] });
      resource.nodes.push({ path: root.path + "/" + unit + "/nested", kernel: { device: 29, inode: 9001 }, events: "populated 0\n", processes: "", children: [] });
    }
  };
  it("rejects a complete empty recursive tree containing a foreign filesystem device", () => {
    fails(r => { recursiveTree(r); if (r.kind === Kind.EmptyProof && r.data.resources[0]!.disposition === Disposition.PositiveEmpty) r.data.resources[0]!.nodes[2]!.kernel.device = 999; }, "cgroup_filesystem");
  });
  it.each([3509189, 9000])("rejects a recursive descendant alias of simultaneous object %s", inode => {
    fails(r => { recursiveTree(r); if (r.kind === Kind.EmptyProof && r.data.resources[0]!.disposition === Disposition.PositiveEmpty) r.data.resources[0]!.nodes[2]!.kernel.inode = inode; }, "cgroup_identity");
  });
  it("does not complete an admitted held payload without its explicit final payload gate closure", () => {
    const f = fixture({ preparation: Preparation.ServiceAdmitted, edit: r => {
      if (r.kind === Kind.EmptyProof) Reflect.deleteProperty(r.data.dispositions[0]!, "payloadGateClosure");
    } });
    expect(() => read(f)).toThrow();
  });
  it.each([Preparation.Reserved, Preparation.ResourceBound, Preparation.ActorsHeld, Preparation.EnqueueReleased, Preparation.ServiceAdmitted, Preparation.PayloadReleased])(
    "retains a created payload gate at partial/final preparation %s and requires its own closure", preparation => {
      expect(read(fixture({ preparation, payloadGateCreated: true })).state).toBe(RetainedChainState.CompleteData);
      fails(r => { if (r.kind === Kind.EmptyProof) r.data.dispositions[0]!.payloadGateClosure = null; }, "payload_gate_closure_missing", { preparation, payloadGateCreated: true });
    });
  it.each([Preparation.Reserved, Preparation.ResourceBound, Preparation.ActorsHeld, Preparation.EnqueueReleased])(
    "explicitly permits a never-created payload gate at %s without fabricated custody", preparation => {
      expect(read(fixture({ preparation, payloadGateCreated: false })).state).toBe(RetainedChainState.CompleteData);
    });
  it("keeps a missing original created gate record incomplete even before service admission", () => {
    const f = fixture({ preparation: Preparation.ResourceBound, payloadGateCreated: true });
    f.records = f.records.filter(r => r.kind !== Kind.PayloadGate);
    f.publicationEvents = selectedEvents(f.publicationEvents, f.records);
    expect(read(f).state).toBe(RetainedChainState.Incomplete);
  });
  it("rejects hidden partial payload debt and invented never-created gate closure", () => {
    fails(r => { if (r.kind === Kind.Closure) r.data.preparations[0]!.payloadGateDigest = null; }, "closure_payload_gates", { preparation: Preparation.ResourceBound, payloadGateCreated: true });
    fails(r => { if (r.kind === Kind.EmptyProof) r.data.dispositions[0]!.payloadGateClosure = { payloadGateDigest: H("f"), originalGateDigest: H("e"), payloadCustodyDigest: H("d"), closedAtEpochMs: 6200 }; }, "payload_gate_closure_missing", { preparation: Preparation.Reserved });
    fails(r => {
      if (r.kind === Kind.Closure) r.data.preparations[0]!.payloadGateDigest = null;
      if (r.kind === Kind.EmptyProof) r.data.dispositions[0]!.payloadGateClosure = null;
    }, "closure_payload_gates", { preparation: Preparation.ResourceBound, payloadGateCreated: true });
  });
  it("keeps unpublished created payload debt in the independent inventory when both closure references are hidden", () => {
    const f = fixture({ preparation: Preparation.ResourceBound, payloadGateCreated: true, edit: r => {
      if (r.kind === Kind.Closure) r.data.preparations[0]!.payloadGateDigest = null;
      if (r.kind === Kind.EmptyProof) r.data.dispositions[0]!.payloadGateClosure = null;
    } });
    f.records = f.records.filter(r => r.kind !== Kind.PayloadGate);
    f.publicationEvents = selectedEvents(f.publicationEvents, f.records);
    expect(read(f).state).toBe(RetainedChainState.Incomplete);
  });
  it.each(["payloadGateDigest", "originalGateDigest", "payloadCustodyDigest"] as const)("rejects a foreign final payload closure %s", field => {
    fails(r => { if (r.kind === Kind.EmptyProof) r.data.dispositions[0]!.payloadGateClosure![field] = H("f"); }, "payload_gate_closure");
  });
  it.each([6001, 6301, 6500, 7001, 20000])("rejects original payload closure time %s outside closure/collection bounds", closedAtEpochMs => {
    fails(r => { if (r.kind === Kind.EmptyProof) r.data.dispositions[0]!.payloadGateClosure!.closedAtEpochMs = closedAtEpochMs; }, "payload_gate_closure");
  });
  it("requires both gates closed before actor discharge and the first queue/empty collection", () => {
    fails(r => { if (r.kind === Kind.EmptyProof) r.data.dispositions[0]!.payloadGateClosure!.closedAtEpochMs = 6260; }, "actor_discharge_missing");
    fails(r => { if (r.kind === Kind.EmptyProof) { r.data.dispositions[0]!.closedAtEpochMs = 6350; r.data.dispositions[0]!.dischargedAtEpochMs = 6360; } }, "queue_not_empty");
    fails(r => { if (r.kind === Kind.EmptyProof) r.data.dispositions[1]!.payloadGateClosure!.closedAtEpochMs = 6260; }, "actor_discharge_missing", { runtimeProviders: true });
  });
  it("rejects closure of another actually created sibling payload gate", () => {
    fails(r => { if (r.kind === Kind.EmptyProof) r.data.dispositions[0]!.payloadGateClosure = structuredClone(r.data.dispositions[1]!.payloadGateClosure); }, "payload_gate_closure", { runtimeProviders: true });
  });
  it.each([Role.Qualification, Role.QRoot])("requires the exact %s prefix even for a valid 64hex id", role => {
    fails(r => { if (r.kind === Kind.Target) r.data.allocations[0]!.unit = `subscription-runtime-${role === Role.Qualification ? "qroot" : "qualification"}-${H("a")}.service`; }, role === Role.Qualification ? "qualification_unit" : "qroot_unit", { role });
  });
  it("binds original payload custody/gate to actual admission and original reservation/binding", () => {
    for (const field of ["reservationDigest", "bindingDigest", "originalEnqueueGateDigest"] as const) {
      fails(r => { if (r.kind === Kind.PayloadGate) r.data[field] = H("f"); }, "payload_gate_binding");
    }
    fails(r => { if (r.kind === Kind.PayloadGate) r.data.custodyProducerId = "TEST-other"; }, "payload_gate_binding");
    fails(r => { if (r.kind === Kind.PayloadGate) r.data.createdAtEpochMs = 401; }, "payload_gate_binding");
    fails(r => { if (r.kind === Kind.ServiceAdmission) r.data.closedPayloadGateDigest = H("f"); }, "payload_gate_admission");
    fails(r => { if (r.kind === Kind.ServiceAdmission) r.data.payloadCustodyDigest = H("f"); }, "payload_gate_admission");
    fails(r => { if (r.kind === Kind.PayloadGate) {
      r.publication.admitted.atEpochMs = 750;
    } }, "payload_gate_admission");
    failsEvents((e, r) => { if (r.kind === Kind.PayloadGate) e.finalValidated = stamp(10000, e.generation, 4); }, "publication_authority_time");
    fails(() => {}, "payload_gate_missing", { preparation: Preparation.ServiceAdmitted, payloadGateCreated: false });
  });
  it("never discovers a sibling/replacement through a shared creator or omits a companion/partial reservation", () => {
    const f = fixture({ runtimeProviders: true });
    const omitted = f.records.filter(r => r.kind !== Kind.Reservation || r.data.reservationId !== U("4"));
    expect(validateScopedRetainedChain(omitted, selectedEvents(f.publicationEvents, omitted), f.expected, Mode.ReadOnlyHistoricalData, 99000).state).toBe(RetainedChainState.Incomplete);
    fails(r => { if (r.kind === Kind.Closure) r.data.reservationDigests.pop(); }, "closure_reservations", { runtimeProviders: true });
    fails(r => { if (r.kind === Kind.Closure) r.data.preparations.pop(); }, "preparation_completeness", { runtimeProviders: true, preparation: Preparation.Reserved });
    fails(r => { if (r.kind === Kind.EmptyProof) r.data.dispositions.pop(); }, "discharge_completeness", { preparation: Preparation.Reserved });
    const foreign = structuredClone(f.records[1]!) as Mutable<ScopedRetainedRecord>; foreign.targetDigest = H("f"); foreign.publication.generation = 201;
    expect(() => validateScopedRetainedChain([...f.records, foreign], [...f.publicationEvents, project(foreign)], f.expected, Mode.ReadOnlyHistoricalData, 99000)).toThrow("foreign_target");
    const relabeled = structuredClone(f.records.find(r => r.kind === Kind.Reservation)!) as Mutable<ScopedRetainedRecord>; relabeled.publication.generation = 200;
    relabeled.publication.admitted = stamp(relabeled.publication.admitted.atEpochMs, 200, 0);
    expect(() => validateScopedRetainedChain([...f.records, relabeled], [...f.publicationEvents, project(relabeled)], f.expected, Mode.ReadOnlyHistoricalData, 99000)).toThrow("foreign_inventory");
  });
  // Red predicate: an unrelated missing completion returns Incomplete before
  // rejecting a well-bound Reservation outside the authoritative inventory.
  it("rejects undeclared inventory even with an unrelated missing completion", () => {
    const f = fixture({ runtimeProviders: true });
    const foreign = structuredClone(f.records.find(r => r.kind === Kind.Reservation)!) as Mutable<ScopedRetainedRecord>;
    foreign.publication.generation = 200;
    foreign.publication.admitted = stamp(foreign.publication.admitted.atEpochMs, 200, 0);
    const obligation = f.records.find(r => r.kind === Kind.ResourceObligation)!;
    f.records.push(foreign);
    f.publicationEvents.push(project(foreign));
    f.publicationEvents = f.publicationEvents.filter(e => e.recordDigest !== digest(obligation));
    expect(() => read(f)).toThrow("foreign_inventory");
  });
  it("enforces both admission gates and the closed all-task graph", () => {
    fails(r => { if (r.kind === Kind.Closure) r.data.preparations[0]!.enqueueReleasedAtEpochMs = 601; }, "enqueue_gate_time");
    fails(r => { if (r.kind === Kind.Closure) r.data.preparations[0]!.payloadReleasedAtEpochMs = 801; }, "payload_gate_time");
    fails(r => { if (r.kind === Kind.Closure) r.data.preparations[0]!.enqueueReleasedAtEpochMs = 5600; }, "enqueue_gate_time");
    fails(r => { if (r.kind === Kind.ActorAdmission) r.data.tasks[1]!.actorPidBirth = "999:99"; }, "task_graph");
    failsEvents((e, r) => { if (r.kind === Kind.ActorAdmission) e.heldReread = stamp(599, e.generation, 3); }, "publication_event_order");
    fails(r => { if (r.kind === Kind.ActorAdmission) r.data.originalGateDigest = H("f"); }, "held_actor_binding");
    fails(r => { if (r.kind === Kind.EmptyProof) r.data.dispositions[0]!.serviceObservation = null; }, "historical_service", { preparation: Preparation.EnqueueReleased });
  });
  it("requires positive retained actor discharge: natural pidfd exit needs no present PID/procfs, surviving actors cannot disappear", () => {
    const f = fixture({ preparation: Preparation.ActorsHeld });
    expect(read(f).state).toBe(RetainedChainState.CompleteData);
    fails(r => { if (r.kind === Kind.EmptyProof) r.data.dispositions[0]!.discharge!.actors.pop(); }, "array_bound");
    fails(r => { if (r.kind === Kind.EmptyProof) r.data.dispositions[0]!.discharge!.actors[1]!.method = DischargeMethod.ScopedAdmissionFence; }, "actor_discharge_invalid");
    fails(r => { if (r.kind === Kind.EmptyProof) r.data.dispositions[0]!.discharge!.fenceDigest = H("f"); }, "actor_fence");
    fails(r => { if (r.kind === Kind.EmptyProof) r.data.dispositions[0]!.discharge = null; }, "actor_discharge_missing");
  });
  it("does not let a discharged wrapper erase its still obligated enqueue descendant", () => {
    const graph: Edit = r => {
      if (r.kind === Kind.ActorAdmission) {
        r.data.chain.actors[1]!.role = ActorRole.Wrapper;
        r.data.chain.actors.push({ role: ActorRole.ManagerSubmitter, pidBirth: "102:12", controlGroup: "/TEST-root-owner.service", parentPidBirth: "101:11" });
        r.data.tasks.push({ actorPidBirth: "102:12", taskBirths: ["102:12"] });
      }
    };
    expect(read(fixture({ edit: graph })).state).toBe(RetainedChainState.CompleteData);
    fails(r => { graph(r); if (r.kind === Kind.EmptyProof) r.data.dispositions[0]!.discharge!.actors.pop(); }, "actor_discharge_incomplete");
    fails(r => { if (r.kind === Kind.EmptyProof) r.data.dispositions[0]!.dischargedAtEpochMs = 6100; }, "actor_discharge_missing");
    fails(r => { if (r.kind === Kind.EmptyProof) r.data.dispositions[0]!.dischargedAtEpochMs = 6700; }, "queue_not_empty");
  });
  it("requires actual service anchor, leaf identity, payload ancestry and effective-filter admission even after service GC", () => {
    fails(r => { if (r.kind === Kind.ServiceAdmission) r.data.invocationAnchor.invocationId = I("f"); }, "service_leaf_binding");
    fails(r => { if (r.kind === Kind.ServiceAdmission) r.data.controlGroup = r.data.controlGroup.slice(0, r.data.controlGroup.lastIndexOf("/")); }, "service_leaf_binding");
    fails(r => { if (r.kind === Kind.ServiceAdmission) r.data.effectiveFilterPolicyDigest = H("f"); }, "service_leaf_binding");
    fails(r => { if (r.kind === Kind.ServiceAdmission) r.data.effectiveFilterAttachments = []; }, "array_bound");
    fails(r => { if (r.kind === Kind.ServiceAdmission) r.data.effectiveFilterAttachments = [H("a")]; }, "leaf_filters");
    fails(r => { if (r.kind === Kind.ServiceAdmission) r.data.payloadAncestry[0]!.controlGroup = "/TEST-foreign.service"; }, "payload_ancestry");
  });
  it("checks every recursively collected owned leaf and descendant without adopting a changed leaf", () => {
    const tree: Edit = r => {
      if (r.kind === Kind.EmptyProof && r.data.resources[0]!.disposition === Disposition.PositiveEmpty) {
        const resource = r.data.resources[0]!, root = resource.nodes[0]!, unit = r.data.queueBefore.relevantUnits[0]!;
        root.children = [unit];
        resource.nodes.push({ path: root.path + "/" + unit, kernel: { device: 29, inode: 9000 }, events: "populated 0\n", processes: "", children: ["nested"] });
        resource.nodes.push({ path: root.path + "/" + unit + "/nested", kernel: { device: 29, inode: 9001 }, events: "populated 0\n", processes: "", children: [] });
      }
    };
    expect(read(fixture({ edit: tree })).state).toBe(RetainedChainState.CompleteData);
    fails(r => { tree(r); if (r.kind === Kind.EmptyProof && r.data.resources[0]!.disposition === Disposition.PositiveEmpty) r.data.resources[0]!.nodes[2]!.events = "populated 1\n"; }, "recursive_population");
    fails(r => { tree(r); if (r.kind === Kind.EmptyProof && r.data.resources[0]!.disposition === Disposition.PositiveEmpty) r.data.resources[0]!.nodes[1]!.kernel.inode++; }, "leaf_incarnation");
    fails(r => { tree(r); if (r.kind === Kind.EmptyProof && r.data.resources[0]!.disposition === Disposition.PositiveEmpty) r.data.resources[0]!.nodes.shift(); }, "parent_present");
  });
  it("rejects populated parent despite empty root procs, missing/recreated parents and incomplete/foreign recursion", () => {
    fails(r => { if (r.kind === Kind.EmptyProof && r.data.resources[0]!.disposition === Disposition.PositiveEmpty) r.data.resources[0]!.nodes[0]!.events = "populated 1\nfrozen 0\n"; }, "recursive_population");
    fails(r => { if (r.kind === Kind.EmptyProof && r.data.resources[0]!.disposition === Disposition.PositiveEmpty) r.data.resources[0]!.identityAfter.kernel.inode++; }, "parent_incarnation");
    fails(r => { if (r.kind === Kind.EmptyProof && r.data.resources[0]!.disposition === Disposition.PositiveEmpty) r.data.resources[0]!.nodes = []; }, "array_bound");
    fails(r => { if (r.kind === Kind.EmptyProof && r.data.resources[0]!.disposition === Disposition.PositiveEmpty) r.data.resources[0]!.nodes[0]!.children = ["missing.service"]; }, "recursive_traversal_incomplete");
    fails(r => { if (r.kind === Kind.EmptyProof && r.data.resources[0]!.disposition === Disposition.PositiveEmpty) {
      const resource = r.data.resources[0]!, root = resource.nodes[0]!;
      root.children = ["TEST-foreign.service"]; resource.nodes.push({ ...structuredClone(root), path: root.path + "/TEST-foreign.service", children: [] });
    } }, "foreign_cgroup");
    fails(r => { if (r.kind === Kind.EmptyProof && r.data.resources[0]!.disposition === Disposition.PositiveEmpty) r.data.resources[0]!.nodes[0]!.events = "ENODEV"; }, "text");
  });
  it("requires complete exact relevant queues before/after recursive collection and teardown", () => {
    fails(r => { if (r.kind === Kind.EmptyProof) r.data.queueAfter.relevantUnits.pop(); }, "queue_units");
    fails(r => { if (r.kind === Kind.EmptyProof) r.data.queueAfter.jobs.push({ jobId: 77, unit: r.data.queueAfter.relevantUnits[0]! }); }, "queue_not_empty");
    fails(r => { if (r.kind === Kind.RetirementFacts) r.data.queueAfter.jobs.push({ jobId: 40, unit: "TEST-foreign.service" }); }, "retirement_queue_reobservation");
  });
  it("allows ENODEV/path absence only AFTER durable empty proof and intent with matching original pins and independent manager facts", () => {
    fails(r => { if (r.kind === Kind.RetirementIntent) r.publication.admitted.atEpochMs = 7001; }, "publication_order");
    fails(r => { if (r.kind === Kind.RetirementFacts) r.data.effects[0]!.submittedAtEpochMs = 8001; }, "retirement_effect_order");
    fails(r => { if (r.kind === Kind.RetirementFacts) r.data.effects.reverse(); }, "retirement_effect_order");
    fails(r => { if (r.kind === Kind.RetirementFacts) r.data.resources[0]!.slice.originalInvocationId = I("f"); }, "manager_retirement_identity");
    fails(r => { if (r.kind === Kind.RetirementFacts) r.data.resources[0]!.kernel.pinnedDirectory.inode++; }, "pinned_retirement_identity");
    fails(r => { if (r.kind === Kind.RetirementFacts) r.data.resources[0]!.kernel.eventsCustodyDigest = H("f"); }, "pinned_retirement_identity");
    fails(r => { if (r.kind === Kind.RetirementFacts) r.data.resources = []; }, "retirement_resource_completeness");
    fails(r => { if (r.kind === Kind.RetirementFacts) r.data.effects[0]!.acceptedJobId = null; }, "retirement_effect_order");
    fails(r => { if (r.kind === Kind.RetirementFacts) r.data.effects[1]!.sliceIdentityBefore!.kernel.inode++; }, "retirement_pre_effect_identity");
    fails(r => { if (r.kind === Kind.RetirementFacts) r.data.effects[0]!.targetDependencyDigestBefore = H("f"); }, "retirement_pre_effect_identity");
    fails(r => { if (r.kind === Kind.RetirementFacts) r.data.resources[0]!.target.observedAtEpochMs = 8400; }, "target_retired_before_slice_effect");
  });
  it.each([Kind.Closure, Kind.ResourceBinding, Kind.ActorAdmission, Kind.ServiceAdmission, Kind.RetirementIntent, Kind.RetirementFacts,
    Kind.RetirementPublication, Kind.FinalReceipt, Kind.OrdinaryTerminal, Kind.KeyedTerminal])("missing %s remains incomplete at the owning historical reader", kind => {
    const f = fixture({ keyed: true });
    f.records = f.records.filter(r => r.kind !== kind);
    f.publicationEvents = selectedEvents(f.publicationEvents, f.records);
    expect(read(f).state).toBe(RetainedChainState.Incomplete);
  });
  it("does not accept missing original obligations, final references or keyed CAS companions", () => {
    fails(r => { if (r.kind === Kind.FinalReceipt) r.data.retirementPublicationDigest = H("f"); }, "final_chain");
    fails(r => { if (r.kind === Kind.KeyedTerminal) r.data.ordinaryTerminalDigests = []; }, "keyed_ordinary_successors", { keyed: true });
    fails(r => { if (r.kind === Kind.KeyedTerminal) r.data.dispatchIntentDigest = H("f"); }, "keyed_successor", { keyed: true });
  });
  it("rejects live reads at/after original expiry and every late durability/finalization boundary even in historical mode", () => {
    const f = fixture();
    expect(() => read(f, Mode.LiveData, 20000)).toThrow("expired_live_data");
    expect(() => read(f, Mode.LiveData, 20001)).toThrow("expired_live_data");
    expect(() => read(f, Mode.LiveData, 11000)).toThrow("future_publication");
    for (const kind of [Kind.EmptyProof, Kind.RetirementIntent, Kind.RetirementFacts, Kind.RetirementPublication, Kind.FinalReceipt, Kind.OrdinaryTerminal, Kind.KeyedTerminal]) {
      failsEvents((e, r) => { if (r.kind === kind) { e.durable = stamp(20000, e.generation, 1); e.readback = stamp(20000, e.generation, 2); if (e.heldReread) e.heldReread = stamp(20000, e.generation, 3); e.finalValidated = stamp(20000, e.generation, 4); } }, "publication_authority_time", { keyed: true });
    }
    failsEvents((e, r) => { if (r.kind === Kind.ServiceAdmission) e.finalValidated = stamp(10000, e.generation, 4); }, "publication_authority_time");
    fails(r => { if (r.kind === Kind.RetirementFacts) r.data.effects[1]!.completedAtEpochMs = 20000; }, "retirement_effect_order");
  });
  it("pins original deadline, allowance, N, attempt identifier and join binding without renewal", () => {
    const f = fixture();
    for (const field of ["deadlineEpochMs", "totalAllowanceMs", "N"] as const) {
      const changed = fixture({ edit: r => { if (r.kind === Kind.Target) r.data.originalCleanupAuthority[field]++; } });
      changed.expected = { ...changed.expected, originalAuthorityDigest: f.expected.originalAuthorityDigest };
      expect(() => read(changed)).toThrow("original_authority");
    }
    for (const field of ["attemptId", "joinDigest", "originalAuthorityDigest"] as const) {
      fails(r => { if (r.kind === Kind.Closure) r.data.cleanupAttempt[field] = field === "attemptId" ? U("e") : H("f"); }, "attempt_bounds");
    }
    fails(r => { if (r.kind === Kind.FinalReceipt) r.data.attemptDigest = H("f"); }, "renewed_attempt");
    expect(read(f, Mode.LiveData, 16000)).toEqual(read(f, Mode.LiveData, 16001));
    expect(f.records[0]!.data).toMatchObject({ originalCleanupAuthority: { N: 7, totalAllowanceMs: 15000, deadlineEpochMs: 20000 } });
  });
  it.each([3000, 4000])("completes immediately from actual early start %s while work authority ends later", actualStart => {
    const f = fixture({ actualStart, allowance: 1000, keyed: true, runtimeProviders: true, twoProviders: true });
    const target = f.records.find((r): r is ScopedRetainedRecord<Kind.Target> => r.kind === Kind.Target)!;
    const closure = f.records.find((r): r is ScopedRetainedRecord<Kind.Closure> => r.kind === Kind.Closure)!;
    expect(target.data.workEndEpochMs).toBeGreaterThan(closure.data.cleanupAttempt.endEpochMs);
    expect(closure.data.cleanupAttempt).toMatchObject({ startedAtEpochMs: actualStart, endEpochMs: actualStart + 1000 });
    expect(closure.data.admissionClosedAtEpochMs).toBe(actualStart);
    expect(read(f, Mode.LiveData, actualStart + 900).state).toBe(RetainedChainState.CompleteData);
    expect(read(f).state).toBe(RetainedChainState.CompleteData);
  });
  it("prepublishes with actual start unknown and preserves every byte, digest, reference and resource name at two early starts", () => {
    const preparation = fixture({ allowance: 1000, keyed: true, runtimeProviders: true, twoProviders: true });
    const prefix = preparation.records.slice(0, preparation.records.findIndex(r => r.kind === Kind.Closure));
    const priorBytes = prefix.map(retainedResourceBytes), priorDigests = prefix.map(digest);
    const target = prefix[0] as ScopedRetainedRecord<Kind.Target>;
    expect(target.data).not.toHaveProperty("cleanupAttempt");
    expect(target.data.originalCleanupAuthority).not.toHaveProperty("startedAtEpochMs");
    prefix.forEach(r => expect(parseScopedRetainedRecordBytes(retainedResourceBytes(r))).toEqual(r));
    expect(validateScopedRetainedChain(prefix, selectedEvents(preparation.publicationEvents, prefix), { ...preparation.expected, attemptDigest: null }, Mode.LiveData, 2900))
      .toEqual({ state: RetainedChainState.Incomplete, missing: [Kind.Closure] });
    const originalNames = retainedResourceNames(retainedResourceLocator(target.data));
    for (const actualStart of [3000, 4000]) {
      const complete = fixture({ actualStart, allowance: 1000, keyed: true, runtimeProviders: true, twoProviders: true });
      const published = complete.records.slice(0, prefix.length);
      expect(published.map(retainedResourceBytes)).toEqual(priorBytes);
      expect(published.map(digest)).toEqual(priorDigests);
      expect(complete.expected.targetDigest).toBe(preparation.expected.targetDigest);
      expect(complete.expected.originalAuthorityDigest).toBe(preparation.expected.originalAuthorityDigest);
      expect(retainedResourceNames(retainedResourceLocator((published[0] as ScopedRetainedRecord<Kind.Target>).data))).toEqual(originalNames);
      expect(read(complete, Mode.LiveData, actualStart + 900).state).toBe(RetainedChainState.CompleteData);
    }
    expect(prefix.map(retainedResourceBytes)).toEqual(priorBytes);
  });
  it("caps the actual first attempt at the original deadline without extending or shortening its allowance", () => {
    const capped = fixture({ actualStart: 19200, allowance: 1000 });
    expect((capped.records.find(r => r.kind === Kind.Closure) as ScopedRetainedRecord<Kind.Closure>).data.cleanupAttempt.endEpochMs).toBe(20000);
    expect(read(capped, Mode.LiveData, 19950).state).toBe(RetainedChainState.CompleteData);
    const f = fixture({ actualStart: 19500, allowance: 1000 });
    const closure = f.records.find((r): r is ScopedRetainedRecord<Kind.Closure> => r.kind === Kind.Closure)!;
    expect(closure.data.cleanupAttempt.endEpochMs).toBe(20000);
    // Full retirement outlasts this attempt: deadline capping cannot mint time.
    expect(() => read(f)).toThrow("publication_authority_time");
    for (const change of [-1, 1]) {
      fails(r => { if (r.kind === Kind.Closure) r.data.cleanupAttempt.endEpochMs += change; }, "attempt_bounds");
    }
    fails(r => { if (r.kind === Kind.Closure) r.data.cleanupAttempt.startedAtEpochMs = 20000; }, "attempt_bounds");
    fails(r => { if (r.kind === Kind.Closure) r.data.admissionClosedAtEpochMs++; }, "closure_time");
    fails(r => { if (r.kind === Kind.Target) r.data.workEndEpochMs = 20001; }, "original_bounds");
    fails(r => { if (r.kind === Kind.ResourceObligation) r.data.originalAuthorityDigest = H("f"); }, "original_authority");
  });
  it("rejects duplicate or forked first closures and a later plausible attempt against the once-pinned digest", () => {
    const f = fixture({ actualStart: 3000, allowance: 1000 });
    const closure = f.records.find((r): r is ScopedRetainedRecord<Kind.Closure> => r.kind === Kind.Closure)!;
    expect(() => validateScopedRetainedChain([...f.records, closure], f.publicationEvents, f.expected, Mode.ReadOnlyHistoricalData, 99000)).toThrow("duplicate_records");
    const fork = structuredClone(closure) as Mutable<typeof closure>;
    fork.publication.generation = 100;
    fork.publication.admitted = stamp(fork.publication.admitted.atEpochMs, 100, 0);
    fork.data.cleanupAttempt.startedAtEpochMs++;
    fork.data.cleanupAttempt.endEpochMs++;
    fork.data.attemptDigest = digest(fork.data.cleanupAttempt);
    expect(() => validateScopedRetainedChain([...f.records, fork], [...f.publicationEvents, project(fork)], f.expected, Mode.ReadOnlyHistoricalData, 99000)).toThrow("duplicate_stage");
    const later = fixture({ actualStart: 4000, allowance: 1000 });
    expect(() => validateScopedRetainedChain(later.records, later.publicationEvents, f.expected, Mode.ReadOnlyHistoricalData, 99000)).toThrow("original_attempt");
    expect(() => validateScopedRetainedChain(f.records, f.publicationEvents, { ...f.expected, attemptDigest: null }, Mode.ReadOnlyHistoricalData, 99000)).toThrow("original_attempt");
  });
  it("rejects every publication at effective early expiry, keeps missing successors incomplete after disposal", () => {
    const options = { actualStart: 3000, allowance: 1000, keyed: true, runtimeProviders: true, twoProviders: true };
    const f = fixture(options);
    expect(() => read(f, Mode.LiveData, 4000)).toThrow("expired_live_data");
    expect(read(f, Mode.ReadOnlyHistoricalData, 99000).state).toBe(RetainedChainState.CompleteData);
    for (const kind of [Kind.Closure, Kind.ResourceUncreated, Kind.EmptyProof, Kind.RetirementIntent, Kind.RetirementFacts,
      Kind.RetirementPublication, Kind.FinalReceipt, Kind.OrdinaryTerminal, Kind.KeyedTerminal]) {
      failsEvents((e, r) => { if (r.kind === kind) { e.durable = stamp(4000, e.generation, 1); e.readback = stamp(4000, e.generation, 2); if (e.heldReread) e.heldReread = stamp(4000, e.generation, 3); e.finalValidated = stamp(4000, e.generation, 4); } },
        "publication_authority_time", { ...options, ...(kind === Kind.ResourceUncreated ? { neverCreated: true, preparation: Preparation.Reserved } : {}) });
    }
    for (const kind of [Kind.RetirementPublication, Kind.FinalReceipt, Kind.OrdinaryTerminal, Kind.KeyedTerminal]) {
      const records = f.records.filter(r => r.kind !== kind);
      const missing = { ...f, records, publicationEvents: selectedEvents(f.publicationEvents, records) };
      expect(read(missing).state).toBe(RetainedChainState.Incomplete);
    }
    fails(r => { if (r.kind === Kind.ResourceBinding) { r.publication.admitted.atEpochMs = 3001; } },
      "publication_authority_time", options);
    fails(r => { if (r.kind === Kind.RetirementFacts) r.data.effects[1]!.completedAtEpochMs = 4000; }, "retirement_effect_order", options);
  });
  it("keeps Controller structurally distinct with exact ordinary-start grammar and no fabricated Runtime or parent", () => {
    const f = fixture({ role: Role.Controller });
    const target = f.records[0] as ScopedRetainedRecord<Kind.Target>;
    expect(target.data.allocations).toHaveLength(1);
    expect(target.data.allocations[0]).toMatchObject({ role: Role.Controller, unit: `subscription-runtime-ordinary-${U("1")}.service`,
      grantDigest: null, installedGrantDigest: null, qualificationId: null, qualificationLocator: H("c") });
    expect(read(f).state).toBe(RetainedChainState.CompleteData);
    fails(r => { if (r.kind === Kind.Target) r.data.allocations[0]!.unit = `subscription-runtime-controller-${U("1")}.service`; }, "controller_unit", { role: Role.Controller });
    fails(r => { if (r.kind === Kind.Target) r.data.allocations[0]!.unit = `subscription-runtime-ordinary-${U("2")}.service`; }, "controller_unit", { role: Role.Controller });
    fails(r => { if (r.kind === Kind.Target) r.data.topology = Topology.RuntimeWithProviders; }, "runtime_composition", { role: Role.Controller });
    fails(r => { if (r.kind === Kind.Target) r.data.allocations[0]!.role = Role.Runtime; }, "single_owned_service", { role: Role.Controller });
    fails(r => { if (r.kind === Kind.Reservation) r.data.parentRuntime = { allocationId: "TEST-parent", startDigest: H("d") }; }, "fabricated_parent_runtime", { role: Role.Controller });
  });
  it("requires each allocation's original qualification locator independently of the helper's exact own-role id", () => {
    const f = fixture({ role: Role.Qualification });
    const target = f.records[0] as ScopedRetainedRecord<Kind.Target>;
    expect(target.data.qualificationLocator).toBe(H("c"));
    expect(target.data.allocations[0]).toMatchObject({ qualificationLocator: H("c"), qualificationId: H("a"), unit: `subscription-runtime-qualification-${H("a")}.service` });
    expect(read(f).state).toBe(RetainedChainState.CompleteData);
    fails(r => { if (r.kind === Kind.Target) r.data.allocations[0]!.qualificationLocator = H("a"); }, "allocation_qualification", { role: Role.Qualification });
    fails(r => { if (r.kind === Kind.Target) r.data.qualificationLocator = H("f"); }, "allocation_qualification", { runtimeProviders: true });
    for (const qualificationLocator of [null, "TEST-q", "c".repeat(63), "c".repeat(65), "C".repeat(64), "g".repeat(64)]) {
      const bad = structuredClone(target) as unknown as { data: Record<string, unknown>; targetDigest: string };
      bad.data.qualificationLocator = qualificationLocator; bad.targetDigest = digest(bad.data);
      expect(() => parseScopedRetainedRecord(bad)).toThrow("text");
    }
    fails(r => { if (r.kind === Kind.Target) r.data.allocations[0]!.qualificationId = H("c"); }, "qualification_unit", { role: Role.Qualification });
    fails(r => { if (r.kind === Kind.Target) r.data.allocations[0]!.qualificationId = H("c"); }, "runtime_unit", { runtimeProviders: true });
  });
  it("leaves v1 valid behavior unchanged and never promotes failed v1 evidence into v2", () => {
    const identity = { scopeDigest: H("a"), installationId: "TEST-i", hostId: "TEST-h", bootId: "TEST-b", supervisorId: "48:100", supervisorUnit: "TEST-root.service",
      supervisorControlGroup: "/TEST-root.service", accountId: "TEST-a", grantDigest: H("b"), inventoryDigest: H("c"), sourceSha: "a".repeat(40), artifactSha: H("d"), deadlineEpochMs: 9999,
      authorityDigest: H("e"), slotId: "TEST-slot", parentStartId: U("1"), dispatchIntentGeneration: 1 };
    const correlation = { schemaVersion: 1 as const, kind: ScopedTerminationKind.Runtime, identity, startId: U("1"), startDigest: H("f"), parentStartDigest: H("f"), reservationGeneration: 1,
      unit: `subscription-runtime-ordinary-${U("1")}.service`, controlGroup: `/subscription.slice/subscription-runtime.slice/subscription-runtime-hosted.slice/subscription-runtime-ordinary-${U("1")}.service`,
      creatorPidBirth: "48:100", creatorControlGroup: "/TEST-root.service" };
    expect(parseScopedStartCorrelation(correlation)).toEqual(correlation);
    const submitter = { pidBirth: "49:101", controlGroup: "/TEST-root.service" };
    const member = { ...correlation, invocationId: I("a"), submitterDigest: scopedDigest(submitter) };
    const chain = { schemaVersion: 1 as const, correlationDigest: scopedDigest(correlation), submitterDigest: member.submitterDigest, actors: [
      { role: ActorRole.Creator, pidBirth: "48:100", controlGroup: "/TEST-root.service", parentPidBirth: null },
      { role: ActorRole.ManagerSubmitter, ...submitter, parentPidBirth: "48:100" },
    ] };
    const observed = { hostId: identity.hostId, bootId: identity.bootId, supervisorBirth: identity.supervisorId, supervisorGroup: identity.supervisorControlGroup,
      invocationId: member.invocationId, invocationAnchor: { invocationId: member.invocationId, device: 29, inode: 99 }, unitGroup: member.controlGroup, creatorBirth: correlation.creatorPidBirth, creatorGroup: correlation.creatorControlGroup };
    const evidence = { schemaVersion: 1 as const, memberDigest: scopedDigest(member), chain,
      discharge: { schemaVersion: 2 as const, chainDigest: scopedDigest(chain), fenceDigest: H("a"), actors: chain.actors.map((a, i) => ({ ...a, method: i === 0 ? DischargeMethod.ScopedAdmissionFence : DischargeMethod.PidfdExit })) },
      identityBefore: observed, identityAfter: observed, queueBefore: "", queueAfter: "", cgroups: [{ path: member.controlGroup, device: 29, inode: 100, events: "populated 0\n", processes: "", children: [] }] };
    expect(() => validateScopedCollectedEvidence(evidence, member)).not.toThrow();
    const operation = { schemaVersion: 1, identity, operationGeneration: 1, members: [member] };
    expect(parseScopedOperation(operation).members).toHaveLength(1);
    const receipt = { schemaVersion: 1, outcome: "receipt_backed", operation, publicationGeneration: 2,
      observations: [{ startId: member.startId, identityUnchanged: true, creatorFenced: true, queueEmpty: true, recursiveEmpty: true, digest: scopedDigest(evidence), evidence }] };
    expect(parseScopedReceipt(receipt).schemaVersion).toBe(1);
    const missingAnchor = { ...evidence, identityAfter: { ...observed, invocationAnchor: null } };
    expect(() => validateScopedCollectedEvidence(missingAnchor as unknown as typeof evidence, member)).toThrow();
    expect(() => validateScopedCollectedEvidence({ ...evidence, cgroups: [] }, member)).toThrow();
    expect(() => parseScopedRetainedRecord(missingAnchor)).toThrow("fields");
    expect(() => parseScopedRetainedRecord(evidence)).toThrow("fields");
    expect(() => parseScopedRetainedRecord(receipt)).toThrow("fields");
    expect(() => parseScopedStartCorrelation(fixture().records[0])).toThrow();
  });
});
