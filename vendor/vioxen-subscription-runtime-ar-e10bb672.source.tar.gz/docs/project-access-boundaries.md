# Project access boundaries

This document defines the provider-neutral access model used for managed
workers. It is separate from provider sandbox flags such as Codex
`workspace-write` or `danger-full-access`.

## Boundary enum

```ts
enum AccessBoundary {
  ReadOnly = "read_only",
  IsolatedWorkspaceWrite = "isolated_workspace_write",
  ProjectScopedControl = "project_scoped_control",
  DangerFullAccess = "danger_full_access",
}
```

## Semantics

- `ReadOnly`: can inspect scoped project state and run read-only diagnostics.
  It cannot write files, create jobs, start workers or push branches.
- `IsolatedWorkspaceWrite`: can write only inside its isolated workspace roots.
  It cannot write registry files, auth roots, `.git` internals, docker sockets
  or create child workers.
- `ProjectScopedControl`: can coordinate a project through brokered operations:
  create project jobs, create project worktrees, start/stop project workers,
  write review markers, integrate commits and push allowed branches. It should
  not receive unrestricted raw shell.
- `DangerFullAccess`: explicit escape hatch for full host access. Launch plans
  must require an explicit acknowledgement before enabling it.

## Enforcement model

The model is intentionally layered:

1. LLM proposes an action.
2. Runtime checks `AccessPolicyService`.
3. Broker executes structured project-control operations.
4. Sandbox enforces filesystem/tool/network limits.
5. Audit/events record decisions without secrets.

Do not rely on prompt instructions or command parsing as the primary safety
mechanism. Command validation is useful as a secondary deny list, but the
reliable boundary is brokered operations plus a sandbox that prevents raw
filesystem and tool escape.

Launch plans include a provider-neutral `CommandPolicy` for adapters that can
intercept tool or shell calls. The policy denies common escape paths such as
`git push`, `tmux`, Docker, SSH-style tools, inline interpreter execution like
`python -c` or `node -e`, direct shell script execution via `sh`/`bash`/`zsh`,
and direct references to scoped registry roots. This layer must fail closed
when an adapter advertises command validation support, but it is still only a
secondary guard. Ordinary safety must not depend on parsing arbitrary shell.

The Codex file-backend adapter enforces this policy at the `RunnerPort`
boundary before spawning provider processes. A denied command returns
`command_policy_denied:*` and the inner runner is not invoked. This makes
command policy an executable guard rather than documentation, while the
filesystem sandbox and broker remain the primary boundary.
Denied commands emit a `command_policy.denied` runtime event with the decision
reason and executable name only. Raw command arguments are not recorded.

## Project Admission Gate

`ProjectScopedControl` also has a project admission gate. Access policy answers
"may this controller perform this kind of operation?". Admission policy answers
"is it safe to start more work right now?".

The gate runs before brokered producer work such as `create_job`,
`create_worktree` and `start_worker`. It blocks producer starts/refills when the
project has unresolved output debt, for example:

- inactive dirty workspaces;
- completed dirty jobs that are not integrated, rejected or archived;
- dirty orphan workspaces found under project-owned roots but not represented
  in the controller registry;
- stale dirty workers;
- active writer conflicts;
- unreadable project state;
- optional disk pressure checks.

`reviewed` is not a consumed-output state. A reviewed marker is useful context
for a drain agent, but the debt remains until output is integrated, rejected,
marked duplicate/superseded or archived with backup.

The admission decision is not a boolean. Under ordinary output debt, producer
work is denied, but drain roles such as `reviewer`, `fastgate`, `integration`
and `adoption` can be admitted as `allowed_for_drain_only`. If the snapshot is
unavailable, stale, unreadable or under disk pressure, the gate fails closed.

Runtime admission is intentionally not an orchestrator. It does not decide which
memory task to run, how many workers to keep alive or how to prioritize
benchmarks. Those strategy decisions belong to the controller/orchestrator
layer. The runtime gate only enforces the safety invariant that new producer
work cannot bypass unresolved project output debt.

Use `codex_goal_project_admission_snapshot` to inspect the read-only snapshot
and optional decision for a proposed operation and worker role.

The same response includes a compact, explicitly non-authoritative `operations`
projection. It reports the observed worker pool by role/state, output-debt count,
available/total host memory, active heavy reviewer/fastgate workers and the current
admission reason. Missing worker observations make the projection partial instead
of turning an observability failure into scheduler authority.

### Scoped independent admission

Admission is scoped to the broker-bound target before a producer decision is
returned. The worker adapter performs a complete registration/writer census,
including entries outside the human-facing preview limit, and compares canonical
physical workspace roots. A target with a pinned source/revision and a disjoint
canonical writable root may be admitted while unrelated dirty, reviewed,
unconsumed or orphan outputs remain visible as a bounded informational backlog.
The decision includes an internal trusted `summary` with the target identity and
backlog count/preview. Scope is never supplied by an MCP flag or caller-owned
request field.

Same, aliased, nested or otherwise potentially overlapping writable roots, an
unreadable target, malformed control registry, disk pressure, or unknown writer
authority fail closed before mutation or provider spawn for every writing role.
The admission broker coordinates only the fresh census/overlap check and the
existing registration or launch-authorization publication. It releases that
short topology section before provider submission or waiting, while preserving
the existing workspace lease, exact patch/continuation checks, receipts and
old-output custody.

The targetless admission snapshot remains an inventory. When no operation or
worker role is requested, it omits the producer verdict and reports the
operations admission projection as unavailable instead of implying that all
work is denied.

## Durable worker handoff and recovery

Use `codex_goal_project_prepare_verifier` for producer-to-verifier handoff. The
broker resolves the configured remote branch with `git ls-remote`, rejects a
stale local source ref, verifies the terminal producer manifest and patch
SHA-256, creates an isolated worktree at the exact base commit and applies the
patch to the index. The pre-start contract must bind `inputPatchHash` to that
exact staged patch, so unrelated staged, unstaged or untracked content fails
closed.

Before `start_worker`, the runtime selects one capacity-eligible account and the
launched worker receives only that account. Account identities are shared across
jobs by default because hosted Codex auth refresh is disabled and artifacts do
not depend on an account lease. Set
`SUBSCRIPTION_RUNTIME_PROJECT_ACCOUNT_EXCLUSIVE_LEASES=1` only for deployments
whose mutable auth home requires a durable TTL lease and fencing token. Exclusive
reservations are released on failed start, brokered stop or review, and otherwise
expire after the task timeout plus grace. Account choice remains a runtime safety
mechanism, not project worker-mix policy.

Bounded project-control operations publish request, result and claim state with
durable atomic files. `codex_goal_project_recover_operations` reconciles a
published result or resumes an unfinished operation under an exclusive claim.
The controller supervisor calls this recovery before starting a new controller
run. Recovery is idempotent at the operation boundary; downstream effects still
use their existing broker idempotency and fencing contracts.

Use `observedWorkspaceRoots` for legacy or shared parent directories that must
be scanned for dirty project output but must not become write targets. For
example, a project may create new child worktrees only under
`/var/data/infinity-context/worktrees`, while still observing legacy
`/var/data/workspaces/infinity-context-*` directories for debt. Do not add a
shared parent such as `/var/data/workspaces` to `workspaceRoots` just to make
admission see old dirty worktrees; `workspaceRoots` is a write-capable scope.

## Edge cases covered by policy tests

- similar path prefixes, for example `/work/project` vs `/work/project-other`;
- `..` traversal through normalized absolute paths;
- symlink escape when a caller provides both requested path and real path;
- direct `.git` internals access;
- direct registry writes by non-broker operations;
- auth root and docker socket access;
- wrong job id, tmux, branch and remote prefixes;
- force pushes unless project scope explicitly allows them;
- launch fail-closed when an adapter cannot enforce the requested boundary.

## Provider sandbox mapping

Provider sandbox settings are still provider-specific low-level controls.
`AccessBoundary` is the higher-level runtime contract:

- `IsolatedWorkspaceWrite` may map to provider `workspace-write` when the
  adapter can enforce the workspace roots.
- `ProjectScopedControl` should expose project-control broker tools and disable
  unrestricted raw shell.
- `DangerFullAccess` may map to provider `danger-full-access`, but only through
  an explicit launch acknowledgement and audit trail.

Current Codex adapter status:

- legacy jobs without `accessBoundary` keep existing behavior except raw
  `providerSandboxMode: "danger-full-access"` is rejected. Full access must use
  `accessBoundary: "danger_full_access"` with explicit acknowledgement;
- `isolated_workspace_write` maps to Codex `workspace-write`. When a runtime
  command policy is present, Codex app-server command approval requests are
  reviewed by the runtime policy before the app-server receives approval.
  App-server turns also receive a strict `workspaceWrite` sandbox policy with
  the active workspace as the only writable root, network disabled and `/tmp` /
  `TMPDIR` excluded from writable roots;
- `isolated_workspace_write` workers normally edit, test and hand off. Open mode
  lets refill children commit into a separate repository at `<workspace>.tool/git`,
  with tool-only `GIT_DIR` and `GIT_WORK_TREE`. The workspace remains a linked
  worktree with its trusted `.git` read-only. A writable git directory inside
  the workspace is unsafe on the root baseline: app-server runs root `git status`
  outside the sandbox, where repository clean filters can execute. Root handoff
  uses the trusted base and includes committed and uncommitted workspace changes;
- terminal dirty isolated workers publish bounded patch, summary and manifest
  handoff artifacts in their exact worker job root. Handoff/review requests can
  safely backfill legacy completed jobs. Existing mismatched artifacts are never
  overwritten, and Project Integration validates manifest hash, base commit,
  artifact ownership and exact changed paths before opening an attempt;
- confirmed integration opens snapshot validated patch bytes into the
  controller job root. Attempts apply only that immutable snapshot after
  repeated SHA-256 checks; later worker-path mutation cannot change integrated
  output. Snapshot cleanup follows controller attempt/audit retention;
- Codex access-boundary jobs keep the manifest's `networkAccess`, with full
  Internet by default. Set `networkAccess: "restricted"` for a child that must
  not have Internet. Strict and open modes never alter that setting;
- provider-side permission expansion and file-change approval requests are
  denied fail-closed. Project integration writes must use brokered integration
  tools instead;
- `danger_full_access` maps to Codex `danger-full-access` only when explicitly
  acknowledged;
- job manifests with an `accessBoundary` are validated before registry write.
  Unsupported or unenforceable boundaries fail closed instead of being stored;
- registry writes also check manifest consistency against `ProjectAccessScope`:
  workspace paths must be inside scoped roots, scoped accounts must match, and
  brokered project-control manifests must match project job/tmux prefixes.
  Existing workspace paths are checked with `realpath` so symlink escapes fail;
- `project_scoped_control` fails closed for ordinary Codex agent launches. A
  controller manifest can operate only through broker MCP tools such as
  `codex_goal_project_create_job`, `codex_goal_project_start`,
  `codex_goal_project_stop`, `codex_goal_project_mark_reviewed`,
  `codex_goal_project_record_failed_no_output`,
  `codex_goal_project_create_worktree`, and the Project Integration lifecycle
  tools `codex_goal_project_open_integration_attempt`,
  `codex_goal_project_apply_worker_output`,
  `codex_goal_project_run_required_checks`,
  `codex_goal_project_commit_approved_changes`,
  `codex_goal_project_push_approved_commit`, and
  `codex_goal_project_reject_integration_attempt`.

A stored `project_scoped_control` manifest is not a live autonomous LLM process.
It does not think, loop, watch status, start children or call broker tools by
itself. It is the policy identity used by a host-side boss, daemon, MCP/CLI/SDK
surface or future restricted LLM launcher when those callers perform brokered
project-control operations.

Codex broker git/worktree operations use fixed structured requests and
`execFile("git", args)` with no shell interpolation. The broker validates
workspace roots, worktree roots, branches, remotes, force-push policy and
commit SHA shape before executing git. Push force mode uses `--force-with-lease`
and is denied unless project scope explicitly allows force push.

## Project controller recipe

For a long-running project coordinator, create a stored controller job with
`accessBoundary: "project_scoped_control"` and a tight `projectAccessScope`.
The controller is a policy anchor for broker calls, not an ordinary raw-shell
writer. It should coordinate child jobs only through project-control tools.

Do not describe the controller as "running" only because the manifest exists in
the registry. A live controller requires a separate execution surface:

- host boss thread, daemon, MCP, CLI or SDK calling broker tools with the
  controller job id;
- or a restricted LLM launcher that exposes only read-only status tools and
  `codex_goal_project_*` broker tools.

If that restricted LLM launcher is not available, keep orchestration in the host
boss/supervisor. Do not substitute `danger_full_access`; that creates an admin
worker, not a project-scoped controller.

`subscription-runtime-codex-goal tool codex_goal_project_controller_start` is
intentionally rejected by the CLI fallback because it creates a one-shot
in-process MCP server and exits immediately after the tool call. A live
controller must be started by a durable MCP/supervisor process that keeps the
provider runner attached for `status`, `stop` and `reconcile`.

The canonical packaged CLI owner for that durable process is
`subscription-runtime-codex-goal controller-supervise`. It creates an in-process
MCP server, starts the controller through that server and keeps the provider
runner attached until SIGINT or SIGTERM. Native MCP/SDK callers may provide the
same durable ownership contract, but one-shot tool calls may not.

Use `codex_goal_project_controller_launch_plan` as the preflight before any live
LLM-controller attempt. It loads the stored controller manifest, builds the
controlled-agent profile and returns either:

- `ok: true` with the exact broker/status tool allow-list and generated profile
  preview;
- or `ok: false` with fail-closed evidence such as
  `provider_cannot_disable_raw_shell`.

For Codex, the controlled-agent profile uses app-server native environment
disablement as the provider-level raw-shell boundary and keeps MCP/dynamic tools
available for the broker allow-list. Deny rules around `git`, `tmux`, shell
wrappers and Docker remain only a defense-in-depth layer. They do not by
themselves prove that raw shell has been removed from the LLM tool surface.

For Claude, the controlled-agent provider generates a strict MCP config and an
`allowedTools` list containing only `mcp__<server>__codex_goal_project_*` and
status tools. It also sends raw host tools such as Bash, Edit, Write, Read,
WebFetch, WebSearch and Task through `disallowedTools` as defense in depth. A
live Claude controller still requires a valid Claude session artifact and must
fail closed when that session cannot be provided.

The controlled-agent MCP lifecycle tools are:

- `codex_goal_project_controller_launch_plan`: build the fail-closed plan;
- `codex_goal_project_controller_start`: start a provider-specific
  controlled-agent only when the plan is ready and the provider can enforce
  broker-only tools. Codex requires `projectAccessScope.authRoot` to match the
  controller `authRootDir` plus a ready allowed account. Claude requires
  `providerKind: "claude"` and `sessionArtifactPath` inside
  `projectAccessScope.authRoot`. The stored controller `prompt.md` becomes the
  live controller objective. `maxGoalTurns` is available for bounded
  smoke/debug runs, not as the normal production orchestration mode;
- `codex_goal_project_controller_status`: read persisted controller session/run
  state and include provider liveness only when the provider instance is still
  attached in this MCP process. The response includes `liveController` with the
  current durable process owner, the persisted owner, whether they match and the
  observed provider status when available. `liveController.live=true` requires
  an attached runner, matching owner metadata, persisted `running` state and no
  observed terminal provider status;
- `codex_goal_project_controller_consume_guidance`: consume pending control
  guidance for the controller manifest's own inbox and record delivery receipts.
  A live controller should call this at the start of each loop and before
  spawning or integrating workers so operator guidance does not remain pending;
- `codex_goal_project_controller_stop`: stop through the safe provider runner;
- `codex_goal_project_controller_reconcile`: reconcile provider liveness through
  the safe provider runner after crash/reboot.

`subscription-runtime-codex-goal controller-supervise` is the durable CLI owner
for a live controller session. It keeps the in-process MCP server and provider
runner alive, calls `codex_goal_project_controller_start`, polls status, and
reconciles and exits when provider status becomes terminal. It stops the
controlled provider on SIGINT/SIGTERM. The one-shot
`subscription-runtime-codex-goal tool codex_goal_project_controller_start`
remains fail-closed because it cannot own provider liveness after process exit.

If `start`, `stop` or `reconcile` return
`controlled_agent_provider_runner_not_connected`, the persisted state exists but
this MCP process does not own the live provider instance. That is not permission
to use `danger_full_access`. Use the owning process, restart from a clean
controller state, or keep orchestration in the host boss/supervisor.

Persisted owner metadata is diagnostic only. It records safe fields such as
owner id, process kind, pid, hostname, runtime version and runtime sha. It never
records auth payloads, prompts, token contents or provider payloads.

Minimum safe scope:

- `registryRoot`: the single worker registry this controller may write through
  the broker;
- `authRoot`: the single provider auth/session root the host-side runtime may
  read to seed the controlled provider session. For Codex this is the
  `authRoot/account/auth.json` tree. For Claude this is the parent root that may
  contain the explicit `sessionArtifactPath`;
- `workspaceRoots`: existing project integration/checkpoint workspaces;
- `worktreeRoots`: parent directories where child worktrees may be created;
- `observedWorkspaceRoots`: read-only parent directories scanned only by the
  admission gate for legacy dirty workspaces and orphan output debt;
- `jobIdPrefixes`: project-specific prefixes for child job ids and job roots;
- `tmuxSessionPrefixes`: project-specific prefixes for child worker sessions;
- `allowedBranches`: branches the controller may integrate or push;
- `allowedGitRemotes`: usually `origin`;
- `allowedAccountIds`: optional account allow-list for child worker manifests.

The expected control loop is:

1. inspect status with read-only tools;
2. create or refill a child worker through `codex_goal_project_refill_worker`,
   or manually create a scoped worktree with
   `codex_goal_project_create_worktree`;
3. create a child job with `codex_goal_project_create_job` when not using the
   refill helper;
4. start it with `codex_goal_project_start` when not using the refill helper;
5. review the child diff and verification evidence;
   for a verifier, prefer `codex_goal_project_prepare_verifier` over a manual
   patch copy or `git apply`;
   if an infrastructure failure produced no authored output, record it with
   `codex_goal_project_record_failed_no_output` instead of review/integration;
   a dirty verifier worktree is accepted only when its preexisting producer
   patch path and SHA-256 are explicitly verified;
6. write a review marker with `codex_goal_project_mark_reviewed`;
7. open the reviewed output with `codex_goal_project_open_integration_attempt`;
8. apply it with `codex_goal_project_apply_worker_output`;
9. run required checks with `codex_goal_project_run_required_checks`;
10. commit with `codex_goal_project_commit_approved_changes`;
11. push with `codex_goal_project_push_approved_commit` or reject with
    `codex_goal_project_reject_integration_attempt`.

Low-level git operations are not controller rights. Policy-controlled merge
rights must go through the Project Integration lifecycle in
`worker-core/integration`: open attempt, apply worker output, run required
checks, create a commit candidate, then push or reject.

The broker rejects child manifests that try to override the controller-owned
scope, request `danger_full_access`, request `project_scoped_control`, use
unapproved accounts, write job roots outside the registry base, or use
workspace paths outside the controller scope.

### Project-control child worker modes

Strict keeps today's filesystem profile and manifest network setting. The
staged `defaultWorkerModeWhenScopeUnset` is `WorkerMode.Strict`; a later one-line
flip to `Open` follows a green canary on a new TEST controller. Until then only
new controllers created with scope `workerMode: "open"` opt in. Scope repair can
only retain the value or tighten it to `"strict"`; absent-to-open is denied.
Only refill children (including verifier children) can receive open manifests.
`create_job` children remain strict. Child scopes do not inherit the field.

Open adds reads of `/opt/nodejs` and `/srv/workers/jobs` to the exact strict
profile, retaining credential-directory denies and root denial. Tools write
only their workspace and sibling tool home's `home`, `tmp`, and optional `git`.
Use `$TMPDIR` for temporary files and fallback artifacts. Read-only children have
no writable git repository or `GIT_*` environment overrides. App-server's own
environment remains unchanged.

Open falls back to strict with a recorded first reason: `not_linux`,
`not_root_baseline`, `contained`, `model_backend`, `execution_engine`,
`bounded_workspace_tools`, `dependency_tools`, `no_project_read_boundary`,
`tool_root_absent`, or `tool_root_foreign`. Gitlinks or preparation failure leave
no tool root, so those jobs stay strict. An owned tool root must pass layout,
secret-root overlap and PATH checks; invalid layouts fail closed. Removing a
stopped job's tool root is the per-job emergency lever. Preparation and effective
mode evidence are recorded separately.

Denied roots are project-level roots, normally present before launch. Missing
paths beneath admitted read roots stay in the profile: Codex applies directory
masks at each command start, including paths created after profile rendering.
Existing denied-root aliases fail closed. Denied roots outside the explicit
open read roots are not added as masks; paths under strict's `:minimal` reads,
such as `/etc` and `/usr`, remain readable unless separately denied by strict.

Accepted v1 limitations: processes started before a denied directory exists
see that directory through the live read mount until they restart. This includes
long-lived exec sessions and background servers; masks apply at sandbox start.
Other projects' code under the admitted job roots is not treated as secret.
Strict's minimal system reads still expose root-only
files such as `/etc/shadow` and `/etc/gshadow`. Open workers can read other jobs'
workspaces and tool homes under `/srv/workers/jobs`, including caches and git
repositories; mirror `repos/` (2770) and workstream `tmp/` (1770) remain protected
by DAC. Never place credentials in worker environment or tool HOME. Full
Internet retains today's access to loopback services and abstract sockets.
Gitlink repositories remain strict with today's submodule metadata exposure.
The prompt forbids moving the worker branch onto newer upstream commits;
violations can produce noisy or failed integration because the handoff compares
against the original base, and Project Integration validates exact changed paths.
This last outcome has not been verified.
