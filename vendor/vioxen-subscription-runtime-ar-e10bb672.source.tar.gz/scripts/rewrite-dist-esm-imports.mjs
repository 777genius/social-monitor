#!/usr/bin/env node
import {
  existsSync,
  readdirSync,
  readFileSync,
  statSync,
  writeFileSync,
} from "node:fs";
import { extname, join } from "node:path";

const explicitExtensions = new Set([
  ".cjs",
  ".css",
  ".js",
  ".json",
  ".mjs",
  ".node",
]);

const importsOnly = process.argv.length === 3 && process.argv[2] === "--imports-only";
if (process.argv.length !== 2 && !importsOnly) throw new Error("unsupported dist rewrite arguments");
let rewritten = 0;
walk("dist");
// One TypeScript authority for runtime and the standalone installed Host.
// Partial source-contract builds explicitly request only import rewriting.
if (!importsOnly) writeFileSync("host-integration/managed-launcher/hosted-host-policy.mjs",
  "// Generated from src/provider-codex/app-server/adapters/hosted-host-policy.ts.\n" +
  readFileSync("dist/provider-codex/app-server/adapters/hosted-host-policy.js", "utf8")
    .replace(/^\/\/# sourceMappingURL=.*$/m, ""));
console.log(`Rewrote extensionless ESM imports in ${rewritten} dist files.`);

function walk(directory) {
  if (!existsSync(directory)) return;
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const fullPath = join(directory, entry.name);
    if (entry.isDirectory()) {
      walk(fullPath);
      continue;
    }
    if (entry.isFile() && (fullPath.endsWith(".js") || fullPath.endsWith(".d.ts"))) {
      rewriteFile(fullPath);
    }
  }
}

function rewriteFile(filePath) {
  const before = readFileSync(filePath, "utf8");
  let after = before.replace(
    /(from\s*["'])(\.{1,2}\/[^"']+)(["'])/g,
    (_match, prefix, specifier, suffix) =>
      `${prefix}${rewriteSpecifier(filePath, specifier)}${suffix}`,
  );
  after = after.replace(
    /(import\s*\(\s*["'])(\.{1,2}\/[^"']+)(["']\s*\))/g,
    (_match, prefix, specifier, suffix) =>
      `${prefix}${rewriteSpecifier(filePath, specifier)}${suffix}`,
  );
  if (filePath.endsWith(".d.ts")) {
    after = after.replace(/^#!.*\n/, "");
  }
  if (
    filePath.endsWith(".d.ts") &&
    !after.startsWith('/// <reference types="node" />')
  ) {
    after = `/// <reference types="node" />\n${after}`;
  }
  if (filePath.endsWith(".d.ts") && !hasModuleSyntax(after)) {
    after = `${after.replace(/\s*$/, "\n")}export {};\n`;
  }

  if (after !== before) {
    writeFileSync(filePath, after);
    rewritten += 1;
  }
}

function hasModuleSyntax(text) {
  const withoutReferences = text.replace(/^\/\/\/ <reference [^\n]+>\n/gm, "");
  return /^\s*(?:import|export)\b/m.test(withoutReferences);
}

function rewriteSpecifier(filePath, specifier) {
  if (explicitExtensions.has(extname(specifier))) return specifier;

  const asFile = join(filePath, "..", `${specifier}.js`);
  if (existsSync(asFile) && statSync(asFile).isFile()) {
    return `${specifier}.js`;
  }

  const asIndex = join(filePath, "..", specifier, "index.js");
  if (existsSync(asIndex) && statSync(asIndex).isFile()) {
    return `${specifier}/index.js`;
  }

  return specifier;
}
