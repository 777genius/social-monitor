import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    include: ["src/**/*.test.ts"],
    globals: true,
    fileParallelism: false,
    testTimeout: 30_000,
  },
});
